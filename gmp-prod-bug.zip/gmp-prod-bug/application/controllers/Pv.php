<?php

class Pv extends CI_Controller
{
  public function log_pv()
  {
    $data["title"] = "Log PV";
    $data["profil"] = $this->User_model->getProfil();
    $data['pv'] = $this->Pv_model->get_pv();
    $this->load->view('user/log_pv', $data);
  }
  public function log_pv_by_id()
  {
    $data["title"] = "Log PV";
    $data["profil"] = $this->User_model->getProfil();
    $data['pv'] = $this->Pv_model->get_pv_by_id($this->session->userdata('member_id'));
    $this->load->view('user/log_pv', $data);
  }
}