<?php

class Test extends CI_Controller
{
  public function index() {
   $this->Withdraw_check_model->index();

}
}