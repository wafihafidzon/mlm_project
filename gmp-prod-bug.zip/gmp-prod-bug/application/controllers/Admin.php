<?php

class Admin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('email') == null && $this->session->userdata('member_id') == null) {
            redirect('keluar');
        }
        $this->load->helper("tgl_indo");
    }
    public function insert_member()
    {
        $this->session->unset_userdata('error');
        $prefix = 'GMPS';
        $member_id = $prefix . strtoupper(substr(uniqid(), 6, 13));

        $upline = $this->input->post('username_upline');
        $sponsor = $this->input->post('username_sponsor');
        $pv = $this->input->post('pv');
        $no_hp = $this->input->post('no_hp');
        $username = $this->input->post('username');
        $nama_lengkap = $this->input->post('nama_lengkap');
        $no_ktp = $this->input->post('ktp');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $bank = $this->input->post('bank');
        $no_rekening = $this->input->post('no_rekening');
        $posisi = $this->input->post('posisi');
        $paket = $this->input->post('paket_id');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $role = $this->input->post('role_member');

        $kloning = $this->input->post('kloning');
        $jml_kloning = $this->input->post('jml_kloning');

        if($kloning != null){
            $this->Test1_model->index($member_id, $paket, $nama_lengkap, $username , $this->session->userdata('member_id'), $email, $password, $role, $jml_kloning);
            redirect('prospek');
        }

        $this->form_validation->set_rules('no_hp', 'Nomor HP', 'required');
        $this->form_validation->set_rules('paket_id', 'Paket', 'required');
        $this->form_validation->set_rules('posisi', 'Posisi', 'required');
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('ktp', 'No Identitas', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('error', 'Form tidak lengkap. Harap isi semua field yang diperlukan.');
            redirect('add_member');
        }

        $isEmpty = $this->Member_model->isEmpty($upline);

        if (strlen($sponsor) != 0) {
            if (@$isEmpty['posisi'] == $posisi || count($isEmpty ?? []) == 2) {
                $this->session->set_flashdata('error', 'Posisi downline sudah terisi');
                redirect('add_member');
            }
        }

        $dataMember = [
            'member_id' => $member_id,
            'nama' => $nama_lengkap,
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role_id' => $role,
            'pv' => 0,
        ];

        $member = $this->Member_model->store($dataMember);

        $dataProfil = [
            'profil_id' => uniqid(),
            'member_id' => $member_id,
            'no_identitas' => $no_ktp,
            'gender' => $jenis_kelamin,
            'wa' => $no_hp,
            'bank' => $bank,
            'rekening' => $no_rekening,
            'nama_rekening' => $nama_lengkap,
        ];

        $profil = $this->Profil_model->store($dataProfil);

        switch ($paket) {
            case 'AUmpTd0eiDiySMkyiR':
                $point_pasangan = 3;
                break;
            case 'ghuSXbKMduS3LMz2Ve':
                $point_pasangan = 5;
                break;
            case 'n2NEePzD6cjti86Aki':
                $point_pasangan = 1;
                break;
        }
        if ($sponsor == null && $upline == null) {
            $posisi = null;
        }

        $network = [
            'network_id' => uniqid(),
            'member_id' => $member_id,
            'sponsor' => $sponsor,
            'upline' => $upline,
            'posisi' => $posisi,
            'paket' => $paket,
            'point_pasangan' => $point_pasangan,
        ];

        $network = $this->Network_model->store($network);

        redirect('prospek');
    }

    public function approval_member($member_id)
    {
        $update = $this->Member_model->update_approval($member_id);
        $member = $this->Member_model->get_data_by_id($member_id);

        if ($member['paket_name'] == 'Silver') {
            $bonusSponsor = 110000;
        } elseif ($member['paket_name'] == 'Gold') {
            $bonusSponsor = 330000;
        } elseif ($member['paket_name'] == 'Platinum') {
            $bonusSponsor = 550000;
        }

        if ($member['paket_name'] == 'Silver') {
            $bonusTitik = 2000;
        } elseif ($member['paket_name'] == 'Gold') {
            $bonusTitik = 6000;
        } elseif ($member['paket_name'] == 'Platinum') {
            $bonusTitik = 10000;
        }

        $this->add_bonus_sponsor($member_id, $bonusSponsor);
        $this->bonusTitik($member_id, $bonusTitik);

        redirect('BonusPasangan');

    }

    public function add_bonus_sponsor($member_id, $amount)
    {
        $member = $this->Member_model->get_data_by_id($member_id);

        if ($member['sponsor_id'] == null) {
            redirect('admin/prospek');
        }

        $wallet_id = uniqid();

        $wallet = [
            'wallet_id' => $wallet_id,
            'member_id' => $member['sponsor_id'],
            'amount' => $amount,
        ];

        $this->Wallet_model->add_bonus_sponsor($wallet, $member_id);
    }

    public function bonusTitik($member_id, $bonus_amount)
    {
        $this->load->model('Member_model');

        $sponsorChain = $this->Member_model->findSponsorChain($member_id);
        $this->processAndSaveBonuses($sponsorChain, $bonus_amount);

    }

    private function processAndSaveBonuses($sponsorChain, $bonus_amount)
    {
        $this->load->model('Wallet_model');

        foreach ($sponsorChain as $chainItem) {
            if (is_array($chainItem) && isset($chainItem['member_id'])) {
                $member_id = $chainItem['member_id'];

                $this->Wallet_model->saveBonusToWallet($member_id, $bonus_amount);
            }
        }
    }

}
