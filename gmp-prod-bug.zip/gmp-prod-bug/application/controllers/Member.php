<?php

class Member extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('email') == null && $this->session->userdata('member_id') == null) {
            redirect('keluar');
        }
        $this->load->helper("tgl_indo");
    }

    public function index()
    {
        $data["title"] = "Beranda";
        $data['paket'] = $this->Paket_model->getPaket();
        $member_id = $this->session->userdata('member_id');
        $data["member"] = $this->Member_model->get_data_by_id($member_id);
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
    }

    public function transfer_pv_stokis()
    {
        $member = $this->Member_model->get_password($this->session->userdata('member_id'));
        $member_id = $this->input->post('member_id');
        $pv = $this->input->post('jumlah_pv');
        $password = $this->input->post('password');

        $getRole = $this->Member_model->get_role($member_id);

        var_dump($getRole['role_id']);
        if (!password_verify($password, $member['password'])) {
            $this->session->set_flashdata('error', 'Password salah');
            redirect('adminView/transfer_pv_stokis');
        }

        if ($getRole['role_id'] != '4' && $getRole['role_id'] != '5') {
            $this->session->set_flashdata('error', 'Penerima PV bukan stokis');
            redirect('adminView/transfer_pv_stokis');
        }

        $this->Member_model->transfer_pv_stokis($this->session->userdata('member_id'), $member_id, $pv);
        $this->session->set_flashdata('success', 'Transfer PV berhasil');
        redirect('adminView/transfer_pv_stokis');
    }

    public function update_password()
    {
        $member = $this->Member_model->get_data_by_id($this->session->userdata('member_id'));

        $password_lama = $this->input->post('password_lama');
        $password_baru = $this->input->post('new_password');

        if (!password_verify($password_lama, $member['member_password'])) {
            $this->session->set_flashdata('error', 'Password lama salah');
            redirect('member/detail_member/' . $this->session->userdata('member_id'));
        }

        $passwordHash =password_hash($password_baru, PASSWORD_DEFAULT);

        $this->Member_model->update_password($this->session->userdata('member_id'), $passwordHash);
        var_dump($member);
    }

    public function transfer_pv()
    {
        $member = $this->Member_model->get_data_by_id($this->session->userdata('member_id'));
        $member_id = $this->input->post('member_id');
        $pv = $this->input->post('jumlah_pv');
        $password = $this->input->post('password');

        if (!password_verify($password, $member['member_password'])) {
            $this->session->set_flashdata('error', 'Password salah');
            redirect('memberView/transfer_pv');
        }

        $penerima_pv = $this->Member_model->get_data_by_id($member_id);

        if ($penerima_pv == null) {
            $this->session->set_flashdata('error', 'Penerima PV tidak ditemukan');
            redirect('memberView/transfer_pv');
        }

        $this->Member_model->transfer_pv($this->session->userdata('member_id'), $member_id, $pv);

        redirect('memberView/transfer_pv');
    }

    public function detail_member($member_id)
    {
        $data['member'] = $this->Member_model->get_data_by_id($member_id);
        $data["profil"] = $this->User_model->get_profil_by_id($member_id);
        $data['bank'] = $this->Bank_model->get_bank_active();
        $data["title"] = "Detail Member";

        $this->load->view('member/detail', $data);
    }

    public function showSponsorChain($member_id)
    {
        $this->load->model('Member_model');

        $sponsorChain = $this->Member_model->findSponsorChain($member_id);

        echo '<pre>';
        print_r($sponsorChain);
        echo '</pre>';
    }

    public function insert_member()
    {
        $prefix = 'GMPS';
        $member_id = $prefix . strtoupper(substr(uniqid(), 6, 13));

        $upline = $this->input->post('username_upline');
        $sponsor = $this->session->userdata('member_id');
        $pv = $this->input->post('pv');
        $no_hp = $this->input->post('no_hp');
        $username = $this->input->post('username');
        $nama_lengkap = $this->input->post('nama_lengkap');
        $no_ktp = $this->input->post('ktp');
        $bank = $this->input->post('bank');
        $no_rekening = $this->input->post('no_rekening');
        $posisi = $this->input->post('posisi');
        $paket = $this->input->post('paket_id');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $role = $this->input->post('role_member');
        $is_pin_kosong = $this->input->post('pin_kosong');

        $this->form_validation->set_rules('username_upline', 'Username Upline', 'required');
        $this->form_validation->set_rules('no_hp', 'Nomor HP', 'required');
        $this->form_validation->set_rules('paket_id', 'Paket', 'required');
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('ktp', 'No Identitas', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('error', 'Form tidak lengkap. Harap isi semua field yang diperlukan.');
            redirect('add_member');
        }

        $kloning = $this->input->post('kloning');
        $jml_kloning = $this->input->post('jmlKloning');

        // if($jml_kloning > 0 || $jml_kloning > 0){
        //     $this->Test1_model->index($member_id, $paket, $nama_lengkap, $username , $this->session->userdata('member_id'), $email, $password, 2 , $jml_kloning, $no_rekening, $bank);
        //   // end();
        //         $this->Member_model->potong_hu($member_id, $jml_kloning);
        //     //redirect('prospek');
        // }
        
        //  $validateNumber = $this->validateNumber($no_hp);

        //  if ($validateNumber != 200) {
        //      $this->session->set_flashdata('error', "Nomer tidak valid");
        //      redirect('memberview/add_member');
        //  }

        $isEmpty = $this->Member_model->isEmpty($upline);

        if (strlen($sponsor) != 0) {
            if (@$isEmpty['posisi'] == $posisi || count($isEmpty ?? []) == 2) {
                $this->session->set_flashdata('error', 'Posisi downline sudah terisi');
                redirect('add_member');
            }
        }

        $dataMember = [
            'member_id' => $member_id,
            'nama' => $nama_lengkap,
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role_id' => 2,
            'pv' => 0,
            // 'is_pin_kosong' => $is_pin_kosong
        ];

        $member = $this->Member_model->store($dataMember);

        $dataProfil = [
            'profil_id' => uniqid(),
            'member_id' => $member_id,
            'no_identitas' => $no_ktp,
            'wa' => $no_hp,
            'bank' => $bank,
            'rekening' => $no_rekening,
            'nama_rekening' => $nama_lengkap,
        ];

        $profil = $this->Profil_model->store($dataProfil);

        switch ($paket) {
            case 'AUmpTd0eiDiySMkyiR':
                $point_pasangan = 3;
                break;
            case 'ghuSXbKMduS3LMz2Ve':
                $point_pasangan = 5;
                break;
            case 'n2NEePzD6cjti86Aki':
                $point_pasangan = 1;
                break;
        }
        if ($sponsor == null && $upline == null) {
            $posisi = null;
        }

        $network = [
            'network_id' => uniqid(),
            'member_id' => $member_id,
            'sponsor' => $sponsor,
            'upline' => $upline,
            'posisi' => $posisi,
            'paket' => $paket,
            'point_pasangan' => $point_pasangan,
        ];

        $network = $this->Network_model->store($network);

        switch ($paket) {
            case 'AUmpTd0eiDiySMkyiR':
                $paket_name = 'Gold';
                break;
            case 'ghuSXbKMduS3LMz2Ve':
                $paket_name = "Platinum";
                break;
            case 'n2NEePzD6cjti86Aki':
                $paket_name = "Silver";
                break;
        }

        $this->Member_model->potong_pv($member, $paket);
        $this->sendMessage($no_hp, $sponsor, $nama_lengkap, $upline, $paket_name, $member_id, $password);

        $this->Network_model->tambah_total_downline($upline, $posisi);

        redirect('prospek');
    }

    public function update_member() {
        $username = $this->input->post('username');
        $nama_lengkap = $this->input->post('nama_lengkap');
        $email = $this->input->post('email');
        $no_ktp = $this->input->post('ktp');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tanggal_lahir = $this->input->post('tanggal_lahir');
        $kota = $this->input->post('kota');
        $provinsi = $this->input->post('provinsi');

        $jumlah_kloning = $this->input->post('jumlah_kloning');
        
        
        
        $bank = $this->input->post('bank');
        $no_rekening = $this->input->post('no_rekening');

        $data = [
            'no_identitas' => $no_ktp,
            'gender' => $jenis_kelamin,
            'tmpt_lahir' => $tempat_lahir,
            'tgl_lahir' => $tanggal_lahir,
            'kota' => $kota,
            'provinsi' => $provinsi,
            'bank' => $bank,
            'rekening' => $no_rekening
        ];

        $dataMember = [
            'username' => $username,
            'nama' => $nama_lengkap,
            'email' => $email,
        ];

        $this->Member_model->update_profil($data, $this->session->userdata('member_id'));
        $this->Member_model->update_member($dataMember, $this->session->userdata('member_id'));

        redirect('detail_member/' . $this->session->userdata('member_id'));
    }

    private function validateNumber($number)
    {
        $dataSending = array();
        $dataSending["api_key"] = "DXZONVIAAPPEQABE";
        $dataSending["number_key"] = "mYL35A8SpU3yiZV4";
        $dataSending["phone_no"] = "$number";
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.watzap.id/v1/validate_number',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($dataSending),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $responseObj = json_decode($response);
        return $responseObj->status;
    }

    private function sendMessage($number, $sponsor, $nama_lengkap, $upline, $paket, $member_id, $password) 
    {
        $dataSending = array();
        $dataSending["api_key"] = "DXZONVIAAPPEQABE";
        $dataSending["number_key"] = "mYL35A8SpU3yiZV4";
        $dataSending["phone_no"] = "$number";
        $dataSending["message"] = 
        "Selamat bergabung di GMP SEJAHTERA Berikut informasi terkait akun anda:
        Paket: $paket
        Sponsor: $sponsor
        Upline: $upline
        
        Nama: $nama_lengkap
        Username: $member_id
        Password: $password
                
        Silakan kunjungi membergmp.gmpsejahtera.co.id untuk masuk ke halaman pribadi anda.
        Untuk keamanan akun, silakan ganti kata sandi secara berkala
                
        Salam Hormat,
        Management GMP SEJAHTERA 
        
        Layanan Pelanggan:
        PT GEO MULIA PERKASA SEJAHTERA";
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.watzap.id/v1/send_message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($dataSending),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $responseObj = json_decode($response);
        return $responseObj->status;
    }
}
