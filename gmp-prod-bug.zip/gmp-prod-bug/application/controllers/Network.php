<?php
class Network extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('email') == null && $this->session->userdata('member_id') == null) {
            redirect('keluar');
        }
        $this->load->model('Network_model');
    }

    public function index()
    {
        if ($this->session->userdata('role_id') == 2) {
            redirect('keluar');
        }
        $data["title"] = "MLM Network Tree";
        $data["profil"] = $this->User_model->getProfil();

        $member_id = $this->uri->segment(3);

        $data['kolom1'] = $this->Network_model->get_network_by_id($member_id ?? $this->session->userdata('member_id'));
        $data['kolom2'] = $this->Network_model->get_kolom($member_id ?? $this->session->userdata('member_id'));
       
        if (isset($data['kolom2']) && @$data['kolom2'][0]['posisi'] == 'Kiri') {
            @$data['kolom2kiri'] = @$data['kolom2'][0];
            @$data['kolom2kanan'] = @$data['kolom2'][1];

            @$data['kolom3kiri'] = $this->Network_model->get_kolom($data['kolom2kiri']['member_id']);
            @$data['kolom3kanan'] = $this->Network_model->get_kolom($data['kolom2kanan']['member_id']);
            
        } elseif(count($data['kolom2']) == 1) {
            @$data['kolom2kanan'] = $data['kolom2'][0];
            @$data['kolom3kanan'] = $this->Network_model->get_kolom($data['kolom2kanan']['member_id']);
        }

        if (isset($data['kolom3kiri']) && @$data['kolom3kiri'][0]['posisi'] == 'Kiri') {
            @$data['kolom3KiriBag1'] = @$data['kolom3kiri'][0];
            @$data['kolom3KiriBag2'] = @$data['kolom3kiri'][1];
            
        } elseif(count($data['kolom3kiri'] ?? []) == 1) {
            $data['kolom3KiriBag2'] = $data['kolom3kiri'][0];
        }

        if (isset($data['kolom3kanan']) && @$data['kolom3kanan'][0]['posisi'] == 'Kanan') {
            @$data['kolom3KananBag1'] = @$data['kolom3kanan'][0];
            @$data['kolom3KananBag2'] = @$data['kolom3kanan'][1];
        } elseif(count($data['kolom3kanan'] ?? []) == 1) {
            @$data['kolom3KananBag2'] = @$data['kolom3kanan'][0];
        }

        // var_dump($data['kolom3KananBag1']);
        $this->load->view('user/test', $data);
    }

}
