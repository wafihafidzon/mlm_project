<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
        if($this->session->userdata('email') == null && $this->session->userdata('member_id') == null){
            redirect('keluar');
        }

        $this->load->helper("tgl_indo");
	}

    public function dasboard(){        
        $data["title"] = "Beranda";
        $data["profil"] = $this->User_model->getProfil();
        
    	// $this->load->view('user/dasboard', $data);
    }

    public function profil(){
        $data["profil"] = $this->User_model->getProfil();
        $data["title"] = $data["profil"]['nama'];
        // var_dump($data);
    	$this->load->view('user/profil', $data);
    }

    public function identitas(){
		$this->form_validation->set_rules('nama', 'Nama', 'required|trim', [
    		'required' => 'Nama Tidak Boleh Kosong'
    	]);
		$this->form_validation->set_rules('email', 'Email', 'required|trim', [
    		'required' => 'Email Tidak Boleh Kosong'
    	]);
		$this->form_validation->set_rules('wa', 'Whatsapp', 'required|trim', [
    		'required' => 'Kontak Whatsapp Tidak Boleh Kosong'
    	]);
        
    	if ($this->form_validation->run() == false) {
            $data["profil"] = $this->User_model->getProfil();
            $data["title"] = $data["profil"]['nama'];
    		$this->load->view('user/profil', $data);
    	}else{
            //$this->auth_model->login(); 
        }
    }
}