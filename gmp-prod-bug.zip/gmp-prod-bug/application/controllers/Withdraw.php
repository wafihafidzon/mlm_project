<?php

class Withdraw extends CI_Controller
{
    public function calculate_withdraw()
    {
        $data['withdraw'] = $this->Withdraw_model->get_data_withdraw();
        $id_withdraw = uniqid();
        
        foreach ($data['withdraw'] as $value) {
          $potongan_admin = $value['amount'] * 10 / 100;
          $potongan_sedekah = $value['amount'] * 2.5 / 100;
          $biaya_transfer = 7000;

          $total_transfer = $value['amount'] - ($potongan_admin + $potongan_sedekah + $biaya_transfer);
          var_dump($value['member_id']);
          $this->Withdraw_model->insertWithdrawDetail($id_withdraw, $value['member_id'], $value['amount'], $potongan_admin, $potongan_sedekah, $biaya_transfer, $total_transfer);
      }   
    }
    public function withdraw()
    {
        $data["title"] = "Withdraw";
        $data["profil"] = $this->User_model->getProfil();
        $data['withdraw'] = $this->Withdraw_model->get_withdraw();
        
        $this->load->view('wallet/withdraw', $data);
    }

    public function withdraw_detail($id)
    {
        $data["title"] = "Withdraw Detail";
        $data["profil"] = $this->User_model->getProfil();
        $data['withdraw'] = $this->Withdraw_model->get_data_withdraw_by_id($id);
        $data['withdraw_id'] = $id;

        // var_dump($data['withdraw']);
        $this->load->view('wallet/withdraw_detail', $data);
    }

    public function withdraw_proses()
    {
        $data = $this->input->post('selectedCheckbox');
        $reject = $this->input->post('action');
        $id = $this->input->post('id');
        
        if($reject != null) {
            foreach ($data as $value) {
                $this->Withdraw_model->reject_amount($value);
            }
        } else {
            $aksi = 'Transferred';
            foreach ($data as $value) {
                $this->Withdraw_model->rubah_status($aksi, $value);
            }
        }

        redirect('withdraw/withdraw_detail/' . $id); 
    }
    public function withdraw_reject()
    {
        $data = $this->input->post('selected_withdraws');
        // $this->Withdraw_model
        var_dump($data);
    }
}
