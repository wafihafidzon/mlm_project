<?php
class BonusPasangan extends CI_Controller
{
   //  public function hitung_kaki($member_id, $poinData = 1)
   //  {
   //      $data = $this->Network_model->get_data_network($member_id);
   //      $poin = 0;
   //      $poin += $poinData;

   //      foreach ($data as $row) {
   //          $upline = $row['upline'];
   //          $posisi = $row['posisi'];

   //          $this->Network_model->tambah_total_downline($upline, $posisi, $poin++);
   //       }
   //       if ($row['upline'] != null) {
   //           $this->hitung_kaki($upline, $poin++);
   //       } else {
   //          $poin = 1;
   //       }
   //       var_dump($row['upline']);
   //  }

    public function hitung_kaki()
    {
        $this->Network_model->getMembersByDate();
      //   $data = $this->Network_model->get_data_network($member_id);
      //   $poidData = 0;
      //   $poidData += $poinData;

      //   foreach ($data as $row) {

      //       if($row['paket'] == "AUmpTd0eiDiySMkyiR") {
      //          $poinData = 3; 
      //       } elseif ($row['paket'] == "n2NEePzD6cjti86Aki") {
      //          $poinData = 1; 
      //       } else {
      //          $poinData = 5;
      //       }
            
      //       $upline = $row['upline'];
      //       $posisi = $row['posisi'];

      //       $this->Network_model->tambah_total_downline($upline, $posisi, $poidData);
      //    }
      //    if ($row['upline'] != null) {
      //        $this->hitung_kaki($upline, $poinData);
      //    } else {
      //       $poin = 1;
      //    }
      //    var_dump($row['upline']);
    }
}
