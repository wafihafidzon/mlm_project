<?php

class MemberView extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('email') == null && $this->session->userdata('member_id') == null) {
            redirect('keluar');
        }
        $this->load->helper("tgl_indo");
    }

    public function index()
    {
        $this->load->view('user/test');
    }

    public function transfer_pv()
    {
        $data["title"] = "Transfer PV";
        $data["profil"] = $this->User_model->getProfil();
        $data['pv'] = $this->Member_model->get_pv($this->session->userdata('member_id'));
        $this->load->view('user/transfer_pv', $data);
    }
    
    public function add_member()
    {
        $data['paket'] = $this->Paket_model->getPaket();
        $data["title"] = "Input Member Baru";
        $data['bank'] = $this->Bank_model->getBank();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $data['member'] = $this->Member_model->get_member_by_id($this->session->userdata('member_id'));
        $data['pv'] = $this->Member_model->get_pv($this->session->userdata('member_id'));
        $data['bank'] = $this->Bank_model->get_bank_active();
        $data['calon_downline'] = $this->uri->segment(3) ?? 'kosong';
        $data['posisi_calon'] = $this->uri->segment(4);
        
        $data['calon_downline'] = $this->input->get('id');
        $data['posisi_calon'] = $this->input->get('posisi');

        $this->load->view('user/add_member', $data);
    }

    public function bonus_sponsor($member_id)
    {
        $data["title"] = "Bonus Sponsor - $member_id";
        $data['bonus'] = $this->Wallet_model->get_data_bonus_sponsor_by_id();
        $data['sum_bonus'] = $this->Wallet_model->get_sum_bonus_sponsor_by_id();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $this->load->view('bonus_member/bonus_sponsor', $data);
    }

    public function bonus_pasangan($member_id)
    {
        $data["title"] = "Bonus Pasangan - $member_id";
        $data['bonus'] = $this->Wallet_model->get_data_bonus_pasangan_by_id();
        $data['sum_bonus'] = $this->Wallet_model->get_sum_bonus_pasangan_by_id();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $this->load->view('bonus_member/bonus_pasangan', $data);
    }

    public function bonus_titik($member_id)
    {
        $data["title"] = "Bonus Titik - $member_id";
        $data['bonus'] = $this->Wallet_model->get_data_bonus_titik_by_id();
        $data['sum_bonus'] = $this->Wallet_model->get_sum_bonus_titik_by_id();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $this->load->view('bonus_member/bonus_titik', $data);
    }

    public function dashboard()
    {
        $data["title"] = "Beranda";
        $data["profil"] = $this->User_model->getProfil();
        $data['saldo_pv'] = $this->Member_model->get_pv($this->session->userdata('member_id'));
        $data['paket'] = $this->Member_model->get_paket($this->session->userdata('member_id'));

        $memberId = $this->session->userdata('member_id');

        $members = $this->Network_model->getMembers();
        $jumlahMemberKaki = $this->hitungJumlahMemberKakiKiriKanan($members, $memberId);
        $data["jumlahMemberKaki"] = $jumlahMemberKaki;

        $this->load->view('user/dasboard', $data);
    }

    private function hitungJumlahMemberKakiKiriKanan($members, $memberId)
    {
        $jumlahMemberKiri = $this->hitungJumlahMemberKaki($members, $memberId, 'Kiri');
        $jumlahMemberKanan = $this->hitungJumlahMemberKaki($members, $memberId, 'Kanan');

        return ['kiri' => $jumlahMemberKiri, 'kanan' => $jumlahMemberKanan];
    }

    private function hitungJumlahMemberKaki($members, $currentMemberId, $direction)
    {
        $jumlahMember = 0;

        foreach ($members as $member) {
            if ($member['upline'] == $currentMemberId && $member['posisi'] == $direction) {
                $jumlahMember += 1; // Tambahkan 1 untuk setiap member di kaki
                $jumlahMember += $this->hitungJumlahMemberKaki($members, $member['member_id'], $direction);
            }
        }
        return $jumlahMember;
    }
}
