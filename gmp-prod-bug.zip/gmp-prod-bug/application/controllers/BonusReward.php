<?php

class BonusReward extends CI_Controller
{
    public function updateMemberStatus()
    {
        $data['distributors'] = $this->Bonus_model->getDistributors();

        foreach ($data['distributors'] as $distributor) {
            $totalPointsNetwork = $this->Bonus_model->calculateTotalPointsNetwork($distributor['member_id']);

            if ($totalPointsNetwork >= 50) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Executive');
            } elseif ($totalPointsNetwork >= 100) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Manager');
            } elseif ($totalPointsNetwork >= 300) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Manager Executive');
            } elseif ($totalPointsNetwork >= 900) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Direktur Executive');
            } elseif ($totalPointsNetwork >= 2700) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Diamond Executive');
            } elseif ($totalPointsNetwork >= 8100) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Crown Executive');
            } elseif ($totalPointsNetwork >= 24300) {
                $this->Bonus_model->updateMemberStatus($distributor['member_id'], 'Royal Crown');
            }
        }

    }
}
