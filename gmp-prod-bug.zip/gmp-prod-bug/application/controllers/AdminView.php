<?php

class AdminView extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('role_id') == null) {
            redirect('keluar');
        }
        $this->load->helper("tgl_indo");
    }
    public function index()
    {
        $data["title"] = "Beranda";
        $data["profil"] = $this->User_model->getProfil();
        $data['network'] = $this->Network_model->get_network_by_id($this->session->userdata('member_id'));
        $data['member'] = $this->Member_model->get_member_by_id($this->session->userdata('member_id'));
        $data['bonus_sponsor'] = $this->Wallet_model->get_sum_bonus_sponsor_by_id();
        $data['bonus_pasangan'] = $this->Wallet_model->get_sum_bonus_pasangan_by_id();
        $data['bonus_titik'] = $this->Wallet_model->get_sum_bonus_titik_by_id();
        $data['bonus_prestasi'] = $this->Network_model->get_status_reward($this->session->userdata('member_id'));
        $data['sedekah_nasional'] = $this->Withdraw_model->sum_sedekah();

        
        $pendaftaran = $this->Network_model->count_pendaftaran();
        $data['silver'] = $pendaftaran['silver'] * 110000;
        $data['gold'] = $pendaftaran['gold'] * 320000;
        $data['platinum'] = $pendaftaran['platinum'] * 550000;
        $data['total'] = $data['silver'] + $data['gold'] + $data['platinum'];
        
        $memberId = $this->session->userdata('member_id');

        $members = $this->Network_model->getMembers();
        $jumlahMemberKaki = $this->hitungJumlahMemberKakiKiriKanan($members, $memberId);
        $data["jumlahMemberKaki"] = $jumlahMemberKaki;

        // var_dump($data['sedekah_nasional']);
        $this->load->view('admin/admin', $data);
    }

    public function pendapatan_perusahaan()
    {
        $data["title"] = "Pendapatan Perusahaan";
        $data["profil"] = $this->User_model->getProfil();

        $data['sum_bonus_pasangan'] = $this->Wallet_model->get_sum_bonus_pasangan();
        $data['sum_bonus_sponsor'] = $this->Wallet_model->get_sum_bonus_sponsor();
        $data['sum_bonus_titik'] = $this->Wallet_model->get_sum_bonus_titik();
        $data['sum_bonus'] = $data['sum_bonus_pasangan']['amount'] + $data['sum_bonus_sponsor']['amount'] + $data['sum_bonus_titik']['amount'];

        $pendaftaran = $this->Network_model->count_pendaftaran();
        $data['silver'] = $pendaftaran['silver'] * 650000;
        $data['gold'] = $pendaftaran['gold'] * 1960000;
        $data['platinum'] = $pendaftaran['platinum'] * 3300000;
        $data['total'] = $data['silver'] + $data['gold'] + $data['platinum'];

        $data['transferred'] = $this->Withdraw_model->sum_transferred();
        $data['pending'] = $this->Withdraw_model->sum_pending();

        $data['wallet'] = $this->Wallet_model->get_wallet_pendapatan();
        // var_dump($data['wallet']);
        $this->load->view('admin/pendapatan_perusahaan', $data);
    }
    public function member_list()
    {
        $data["member"] = $this->Member_model->get_data();
        $data["profil"] = $this->User_model->getProfil();
        $data["title"] = "Input Member Baru";
        
        //var_dump($data['member']);
        //echo '<pre>' . var_export($data['member'], true) . '</pre>';
        $this->load->view('admin/member', $data);
    }

    public function transfer_pv_stokis()
    {
        $data["title"] = "Transfer PV Stokis";
        $data["profil"] = $this->User_model->getProfil();
        $data['pv'] = $this->Member_model->get_pv($this->session->userdata('member_id'));
        $this->load->view('user/transfer_pv_stokis', $data);
    }

    public function add_member()
    {
        $data['paket'] = $this->Paket_model->getPaket();
        $data["title"] = "Input Member Baru";
        $data['bank'] = $this->Bank_model->getBank();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $data['member'] = $this->Member_model->get_member_by_id($this->session->userdata('member_id'));
        $data['pv'] = $this->Member_model->get_pv($this->session->userdata('member_id'));
        $data['bank'] = $this->Bank_model->get_bank_active();
        $data['calon_downline'] = $this->uri->segment(3) ?? 'kosong';
        $data['posisi_calon'] = $this->uri->segment(4);

        $this->load->view('user/add_member', $data);
    }

    public function prospek()
    {
        $data["member"] = $this->Member_model->get_data_prospek();
        $data["profil"] = $this->User_model->getProfil();
        $data["title"] = "Prospek Member";
        $this->load->view('admin/prospek', $data);
    }

    public function bonus_sponsor()
    {
        $data["title"] = "Bonus Sponsor";
        $data['bonus'] = $this->Wallet_model->get_data_bonus_sponsor();
        $data['sum_bonus'] = $this->Wallet_model->get_sum_bonus_sponsor();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $this->load->view('bonus/bonus_sponsor', $data);
    }

    public function bonus_pasangan()
    {
        $data["title"] = "Bonus Pasangan";
        $data['bonus'] = $this->Wallet_model->get_data_bonus_pasangan();
        $data['sum_bonus'] = $this->Wallet_model->get_sum_bonus_pasangan();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $this->load->view('bonus/bonus_pasangan', $data);
    }

    public function bonus_titik()
    {
        $data["title"] = "Bonus Titik";
        $data['bonus'] = $this->Wallet_model->get_data_bonus_titik();
        $data['sum_bonus'] = $this->Wallet_model->get_sum_bonus_titik();
        $data["profil"] = $this->User_model->getProfil($this->session->userdata('member_id'));
        $this->load->view('bonus/bonus_titik', $data);
    }

    public function wallet()
    {
        $data["profil"] = $this->User_model->getProfil();
        $data["title"] = "Wallet";
        $data['wallet'] = $this->Wallet_model->get_wallet();
        $this->load->view("wallet/wallet", $data);
    }

    public function detail_wallet($member_id)
    {
        $data["profil"] = $this->User_model->getProfil();
        $data["title"] = "Detail Wallet";
        $data['member_id'] = $member_id;
        $data['wallet'] = $this->Wallet_model->get_detail_wallet($member_id);
        $this->load->view("wallet/detail_wallet", $data);
    }

    private function hitungJumlahMemberKakiKiriKanan($members, $memberId)
    {
        $jumlahMemberKiri = $this->hitungJumlahMemberKaki($members, $memberId, 'Kiri');
        $jumlahMemberKanan = $this->hitungJumlahMemberKaki($members, $memberId, 'Kanan');

        return ['kiri' => $jumlahMemberKiri, 'kanan' => $jumlahMemberKanan];
    }

    private function hitungJumlahMemberKaki($members, $currentMemberId, $direction)
    {
        $jumlahMember = 0;

        foreach ($members as $member) {
            if ($member['upline'] == $currentMemberId && $member['posisi'] == $direction) {
                $jumlahMember += 1; // Tambahkan 1 untuk setiap member di kaki
                $jumlahMember += $this->hitungJumlahMemberKaki($members, $member['member_id'], $direction);
            }
        }
        return $jumlahMember;
    }
}