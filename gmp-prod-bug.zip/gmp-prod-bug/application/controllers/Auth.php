<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
 * GMP - PT Geo Mulia Perkasa
 */
class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("auth_model");
        $this->load->model("logs_model");
    }

    public function index()
    {
        if ($this->session->userdata('email') != null && $this->session->userdata('member_id') != null) {
            redirect('beranda');
        }
        $this->form_validation->set_rules('email', 'Email', 'required|trim', [
            'required' => 'Username / Email Tidak Boleh Kosong',
        ]);

        $this->form_validation->set_rules('password', 'Password', 'required|trim', [
            'required' => 'Kata Sandi Tidak Boleh Kosong',
        ]);

        if ($this->form_validation->run() == false) {

            $data["title"] = SITE_NAME . " - Masuk";
            $this->load->view('auth/login', $data);
        } else {
            $this->auth_model->login();
        }
    }

    public function login()
    {
        if ($this->session->userdata('email') != null && $this->session->userdata('member_id') != null) {
            redirect('beranda');
        }
        $this->form_validation->set_rules('email', 'Email', 'required|trim', [
            'required' => 'Username / Email Tidak Boleh Kosong',
        ]);

        $this->form_validation->set_rules('password', 'Password', 'required|trim', [
            'required' => 'Kata Sandi Tidak Boleh Kosong',
        ]);

        if ($this->form_validation->run() == false) {
            $data["title"] = SITE_NAME . " - Masuk";
            $this->load->view('auth/login', $data);
        } else {
            $this->auth_model->login();
        }
    }

    public function register()
    {
        if ($this->session->userdata('email') != null && $this->session->userdata('member_id') != null) {
            redirect('beranda');
        }
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[member.email]', [
            'required' => 'Email Tidak Boleh Kosong',
            'valid_email' => 'Format Email tidak Valid',
            'is_unique' => 'Email Sudah Terdaftar',
        ]);
        $this->form_validation->set_rules('password', 'Kata Sandi', 'required|trim|min_length[5]|matches[password2]', [
            'required' => 'Kata Sandi Tidak Boleh Kosong',
            'matches' => 'Kata Sandi tidak sama',
            'min_length' => 'Kata Sandi Minimal 5 Karakter',
        ]);
        $this->form_validation->set_rules('password2', 'Ulangi Kata Sandi', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data["title"] = SITE_NAME . " - Daftar";
            $this->load->view('auth/register', $data);
        } else {
            $this->auth_model->register();
        }
    }

    public function recover()
    {
        $id = $this->uri->segment(2);
        $this->form_validation->set_rules('password', 'Kata Sandi', 'required|trim|min_length[5]|matches[password2]', [
            'required' => 'Kata Sandi Tidak Boleh Kosong',
            'matches' => 'Kata Sandi tidak sama',
            'min_length' => 'Kata Sandi Minimal 5 Karakter',
        ]);
        $this->form_validation->set_rules('password2', 'Ulangi Kata Sandi', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data["title"] = SITE_NAME . " - Ganti Kata Sandi";
            $this->load->view('auth/recover', $data);
        } else {
            $this->auth_model->recoverPass($id);
        }
    }

    public function forgot()
    {
        if ($this->session->userdata('email') != null && $this->session->userdata('member_id') != null) {
            redirect('beranda');
        }
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email', [
            'required' => 'Email Tidak Boleh Kosong',
            'valid_email' => 'Format Email tidak Valid',
        ]);
        if ($this->form_validation->run() == false) {
            $data["title"] = SITE_NAME . " - Lupa Kata Sandi";
            $this->load->view('auth/forgot', $data);
        } else {
            $this->auth_model->forgot();
        }
    }

    public function logout()
    {
        if ($this->session->userdata('member_id') == null) {
            redirect('masuk');
        }
        $this->logs_model->logout();
    }

    public function reset()
    {
        $hashcode = $this->uri->segment(2);
        $cek = $this->auth_model->resetPassword($hashcode);
        if ($cek) {
            redirect('ganti/' . $cek['member_id']);
        } else {
            $this->session->set_flashdata('message', 'gagal.Pemulihan kata sandi gagal. Silakan coba lagi!');
            redirect('lupa');
        }
    }

    public function email_reg()
    {
        $data["title"] = SITE_NAME;
        $this->load->view('auth/email_reg', $data);
    }

    public function email_for()
    {
        $data["title"] = SITE_NAME;
        $this->load->view('auth/email_for', $data);
    }

    public function nf()
    {
        $data["title"] = SITE_NAME;
        $this->load->view('auth/nf404', $data);
    }
}
