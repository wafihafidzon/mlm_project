<?php 

class Bank extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('bank_model');
    $this->load->helper('url_helper');
  }
  public function index()
  {
    $data["title"] = "Data Bank";
    $data["profil"] = $this->User_model->getProfil();
    $data['bank'] = $this->bank_model->getBank();
    $this->load->view('bank/index', $data);
  }

  public function update_status($bank_id)
  {
    $status = $this->input->post('status');
    $this->bank_model->update_status($bank_id, $status);
    redirect('bank');
  }
}