<?php

class Watest extends CI_Controller
{
    public function validateNumber()
    {
        $dataSending = array();
        $dataSending["api_key"] = "DXZONVIAAPPEQABE";
        $dataSending["number_key"] = "mYL35A8SpU3yiZV4";
        $dataSending["phone_no"] = "085736860921";
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.watzap.id/v1/validate_number',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($dataSending),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $responseObj = json_decode($response);
        echo $response;
    }

    public function kirimPesan()
    {
        $dataSending = array();
        $dataSending["api_key"] = "DXZONVIAAPPEQABE";
        $dataSending["number_key"] = "mYL35A8SpU3yiZV4";
        $dataSending["phone_no"] = "6285736745916";
        $dataSending["message"] = 
        "Selamat bergabung di GMP SEJAHTERABerikut informasi terkait akun anda:
        Paket: RESELLER
        Sponsor: TINA MARYATUN(t4XrJF)
        Upline: MISNEM(milyardermisnem)
        
        Nama: NOVA MELDIONO
        Username: milyardernova
        Password: JAGUAR1234
                
        Silakan kunjungi membergmp.gmpsejahtera.co.id untuk masuk ke halaman pribadi anda.
        Untuk keamanan akun, silakan ganti kata sandi secara berkala
                
        Salam Hormat,
        Management GMP SEJAHTERA 
        Ini adalah pesan otomatis, tidak perlu dibalas
        
        Layanan Pelanggan:
        PT GEO MULIA PERKASA SEJAHTERA";
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.watzap.id/v1/send_message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($dataSending),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        echo $response;
    }

    private function sendRequest($url, $data)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }
}
