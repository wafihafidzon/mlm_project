<?php
defined('BASEPATH') or exit('No direct script access allowed');
/*
 * GMP - PT Geo Mulia Perkasa
 */

$autoload['packages'] = array();
$autoload['libraries'] = array('database', 'table', 'form_validation', 'session', 'email');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'file');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array('Auth_model', 'Logs_model', 'Profil_model', 'User_model', 'Network_model', 'Paket_model', 'Member_model', 'Wallet_model', 'Bonus_model', 'Bank_model', 'Withdraw_model', 'Pv_model', 'Test1_model', 'Withdraw_check_model');
