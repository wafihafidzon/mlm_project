<?php
defined('BASEPATH') or exit('No direct script access allowed');

$route['default_controller'] = 'auth';
$route['404_override'] = 'auth/nf';
$route['translate_uri_dashes'] = false;

//Auth
$route['masuk'] = 'auth/login';
$route['daftar'] = 'auth/register';
$route['keluar'] = 'auth/logout';
$route['lupa'] = 'auth/forgot';
$route['reset/(:any)'] = 'auth/reset';
$route['ganti/(:any)'] = 'auth/recover';
$route['emailreg'] = 'auth/email_reg';
$route['emailfor'] = 'auth/email_for';

//User
$route['beranda'] = 'AdminView/index';
$route['profil'] = 'AdminView/index';
//$route['profil'] = 'user/profil';

$route['profil/identitas'] = 'user/identitas';
$route['profil/pekerjaan'] = 'user/pekerjaan';
$route['profil/alamat'] = 'user/alamat';
$route['profil/password'] = 'user/password';

//admin
$route['dashboard'] = 'AdminView/index';
$route['member'] = 'AdminView/member_list';
$route['prospek'] = 'AdminView/prospek';
$route['memberview/add_member'] = 'AdminView/add_member';
$route['add_member'] = 'AdminView/add_member';
$route['memberview/transfer_pv'] = 'MemberView/transfer_pv';

$route['insert_member'] = 'member/add_user';
$route['detail_member/(:any)'] = 'member/detail_member/$1';

$route['hitung-bonus-pasangan'] = 'BonusPasangan';

$route['bonus-peringkat'] = 'adminView/updateMemberStatus';

$route['bonus-pasangan'] = 'adminView/bonus_pasangan';
$route['bonus-pasangan/(:any)'] = 'memberView/bonus_pasangan/$1';

$route['bonus-sponsor'] = 'adminView/bonus_sponsor';
$route['bonus-sponsor/(:any)'] = 'memberView/bonus_sponsor/$1';

$route['bonus-titik'] = 'adminView/bonus_titik';
$route['bonus-titik/(:any)'] = 'memberView/bonus_titik/$1';

$route['wallet'] = 'AdminView/wallet';
$route['detail-wallet/(:any)'] = 'AdminView/detail_wallet/$1';

$route['bank'] = 'bank/index';

$route['adminview/transfer_pv_stokis'] = 'AdminView/transfer_pv_stokis';
$route['adminview/pendapatan_perusahaan'] = 'AdminView/pendapatan_perusahaan';
