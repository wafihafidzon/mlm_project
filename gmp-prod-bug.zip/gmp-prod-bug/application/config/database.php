<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
* GMP - PT Geo Mulia Perkasa
*/

$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
	'dsn'	=> '',
	// 'hostname' => '191.96.56.1',
	//'hostname' => 'srv825.hstgr.io',
	//'phpmyadmin' => 'https://auth-db825.hstgr.io/'
	// 'username' => 'u756850892_gmp',
	// 'password' => 'U756850892_gmp',
	// 'database' => 'u774005669_gmp_clone_prod',
	// 'hostname' => '153.92.15.4',
	// 'username' => 'u774005669_gmpbetaserver',
	// 'password' => 'K3n4ng@npw',
	// 'database' => 'u774005669_database_prod',
	'hostname' => 'localhost',
	'username' => 'root',
	'password' => 'root',
	'database' => 'gmp',
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);
