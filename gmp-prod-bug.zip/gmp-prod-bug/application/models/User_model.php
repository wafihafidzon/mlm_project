<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');
/*
* GMP - PT Geo Mulia Perkasa
*/
class User_model extends CI_Model{
    public function getProfil(){
        
        //SELECT profil_id, member_id, alamat, kota, provinsi, foto_profil, wa, identitas, no_identitas, tgl_lahir, tmpt_lahir, gender, nama_rekening, rekening, bank, kota_rekening, cabang_rekening, npwp, agama, profil.data_update, profil.data_created FROM profil INNER JOIN member ON member.member_id=profil.member_id WHERE profil.member_id = '61ac37c436dfd'
        $this->db->select('member.nama, member.email, alamat, kota, provinsi, foto_profil, wa,identitas, no_identitas, tgl_lahir, tmpt_lahir, gender, nama_rekening, rekening, bank, kota_rekening, cabang_rekening, npwp, agama, profil.data_update, profil.data_created');
        $this->db->join('member', 'member.member_id=profil.member_id');
        $this->db->where('profil.member_id', $this->session->userdata('member_id'));
        $hasil = $this->db->get('profil'); 
        return $hasil->row_array();
    }
    public function get_profil_by_id($member_id){
        
        //SELECT profil_id, member_id, alamat, kota, provinsi, foto_profil, wa, identitas, no_identitas, tgl_lahir, tmpt_lahir, gender, nama_rekening, rekening, bank, kota_rekening, cabang_rekening, npwp, agama, profil.data_update, profil.data_created FROM profil INNER JOIN member ON member.member_id=profil.member_id WHERE profil.member_id = '61ac37c436dfd'
        $this->db->select('member.nama, member.email, alamat, kota, provinsi, foto_profil, wa,identitas, no_identitas, tgl_lahir, tmpt_lahir, gender, nama_rekening, rekening, bank, kota_rekening, cabang_rekening, npwp, agama, profil.data_update, profil.data_created');
        $this->db->join('member', 'member.member_id=profil.member_id');
        $this->db->where('profil.member_id', $member_id);
        $hasil = $this->db->get('profil'); 
        return $hasil->row_array();
    }
}