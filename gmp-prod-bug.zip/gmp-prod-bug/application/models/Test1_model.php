 <?php
class Test1_model extends CI_Model
{
    public function index($memberid, $paket, $nama, $username, $sponsor_id, $email, $password, $role, $jml_kloning, $rekening, $bank)
    {
        $sponsor = $sponsor_id;
        $id = 'GMPSBC1CC3A';

        for ($i = 0; $i < $jml_kloning; $i++) {

            $prefix = 'GMPS';
            $member_id = $prefix . strtoupper(substr(uniqid(), 6, 13));

            $dataMember = [
                'member_id' => $member_id,
                'nama' => $nama,
                'username' => $username,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role_id' => $role,
                'pv' => 0,
            ];

            $this->Member_model->store($dataMember);

            $dataProfil = [
                'profil_id' => uniqid(),
                'member_id' => $member_id,
                'rekening' => $rekening,
                'bank' => $bank,
            ];

            $this->Member_model->input_profil($dataProfil);

            $this->Member_model->potong_pv($sponsor_id, $paket);
            
            $data = $this->db->select('*');
            $data = $this->db->where('upline',$id);
            $data = $this->db->limit(2);
            $data = $this->db->get('network');
            $data = $data->result_array();
           
            if(count($data) == null){
                //$this->db->insert('network', ['network_id' => uniqid(), 'member_id' => $member_id, 'upline' => $id, 'sponsor' => $sponsor, 'posisi' => 'Kiri', 'paket' => $paket]);
                $id = $id;
            echo $id." ";
            }elseif(count($data) == 1){
                
                $posisiBaru = ($data[0]['posisi'] == 'Kiri') ? 'Kanan' : 'Kiri';
                //$this->db->insert('network', ['network_id' => uniqid(), 'member_id' => $member_id, 'upline' => $id, 'sponsor' => $sponsor, 'posisi' => $posisiBaru, 'paket' => $paket]);
                
                $id = $data[0]['member_id'];
            echo $id." ";
            }elseif(count($data) == 2){
                //echo $data[0]['posisi'] ." - ".$data[0]['member_id']."<br/>";
                //echo $data[1]['posisi'] ." - ".$data[1]['member_id']."<br/>";
                //echo '<pre>';
                //    print_r($data);
                //echo '</pre>';
                
                $data2 = $this->db->select('*');
                $data2 = $this->db->where('upline',$data[0]['member_id']);
                $data2 = $this->db->limit(2);
                $data2 = $this->db->get('network');
                $data2 = $data2->result_array();
                
                $id = $data2[0]['member_id'];
            echo $id." ";
                
            }
            //echo $id." ";
            
            
            
            
            //$data = $this->db->get_where('network', ['upline' => $id],limit(10))->limit(10)->result_array();
            
            
            //var_dump($data[0]['posisi']);
            //echo $id ."<br/>";
               // echo '<pre>';
                //print_r(count($data));
               // print_r($data);
               // echo '</pre>';

            if ($data == null) {
                //$id = $id;
                //$this->db->insert('network', ['network_id' => uniqid(), 'member_id' => $member_id, 'upline' => $id, 'sponsor' => $sponsor, 'posisi' => 'Kiri', 'paket' => $paket]);
                $id = $id;
                //$id = $data[0]['member_id'];
            }elseif (count($data) == 1) {
                $posisiBaru = ($data[0]['posisi'] == 'Kiri') ? 'Kanan' : 'Kiri';
                //$this->db->insert('network', ['network_id' => uniqid(), 'member_id' => $member_id, 'upline' => $id, 'sponsor' => $sponsor, 'posisi' => $posisiBaru, 'paket' => $paket]);
                //$id = $data[0]['member_id'];
                
            }elseif (count($data) == 2) {
                
                
                //$data2 = $this->db->get_where('network', ['upline' => $id])->result_array();
                //$id = $data2[0]['member_id'];

            }
            
        }
    }

}