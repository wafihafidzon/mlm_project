<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Bonus_model extends CI_Model
{
  public function pointReedem($cashOutAmount, $memberId)
  {
    $this->db->set('reedem_point', 'reedem_point+' . $cashOutAmount, FALSE);
    $this->db->where('member_id', $memberId);
    $this->db->update('network');
  }

  public function getReedemPoint($memberId)
  {
    $this->db->select('reedem_point, paket');
    $this->db->from('network');
    $this->db->where('member_id', $memberId);
    return $this->db->get()->row_array();
  }

  public function isBonusClaimed($memberId, $redeemablePoints)
    {
        $this->db->where('member_id', $memberId);
        $this->db->where('claimed_points', $redeemablePoints);
        $result = $this->db->get('bonus_claim')->row_array();

        return !empty($result);
    }
  
    public function getDistributors() {
      $query = $this->db->get('network');
      return $query->result_array();
  }

  public function updateMemberStatus($memberId, $newStatus) {
      // Mengupdate status member
      $this->db->where('member_id', $memberId);
      $this->db->update('network', array('status_reward' => $newStatus));
  }

  public function calculateTotalPointsNetwork($memberId) {
      $totalPointsKiri = $this->calculateTotalPoints($memberId, 'Kiri');
      $totalPointsKanan = $this->calculateTotalPoints($memberId, 'Kanan');
      return min($totalPointsKiri, $totalPointsKanan);
  }

  private function calculateTotalPoints($memberId, $side, $excludeSelf = true) {
      $totalPoints = 0;

      if (!$excludeSelf) {
          $this->db->select_sum('point_pasangan', 'total_points');
          $this->db->where('member_id', $memberId);
          $this->db->where('posisi', $side);
          $query = $this->db->get('network');
          $result = $query->row_array();
          $totalPoints += $result['total_points'];
      }

      // Rekursi untuk menghitung total poin dari semua downline
      $downlineMembers = $this->getDownlineMembers($memberId, $side);
      foreach ($downlineMembers as $downline) {
          $totalPoints += $this->calculateTotalPoints($downline['member_id'], $side, false);
      }

      return $totalPoints;
  }

  private function getDownlineMembers($memberId, $side) {
      // Mengambil data downline dari suatu member
      $this->db->where('sponsor', $memberId);
      $this->db->where('posisi', $side);
      $query = $this->db->get('network');
      return $query->result_array();
  }
}