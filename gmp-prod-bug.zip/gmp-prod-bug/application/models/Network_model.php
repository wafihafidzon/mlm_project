<?php defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
 * GMP - PT Geo Mulia Perkasa
 */
class Network_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function store($data)
    {
        $this->db->insert('network', $data);
        return $this->db->insert_id();
    }

    public function get_network_by_id($memberId)
    {
        $this->db->select('n.*, p.nama as nama_paket, m.nama as nama_member');
        $this->db->from('network AS n');
        $this->db->join('paket as p', 'n.paket = p.paket_id');
        $this->db->join('member AS m', 'n.member_id = m.member_id');
        $this->db->where('n.member_id', $memberId);
        return $this->db->get()->row_array();
    }

    public function get_data_network($memberId)
    {
        $this->db->select('n.*');
        $this->db->from('network AS n');
        $this->db->where('n.member_id', $memberId);
        return $this->db->get()->result_array();
    }
    public function getChildren($parentID)
    {
        $this->db->select('n.*');
        $this->db->from('network AS n');
        $this->db->join('member AS m', 'n.member_id = m.member_id');
        $this->db->where('n.sponsor', $parentID);
        return $this->db->get()->result_array();
    }

    public function getUpline($upline)
    {
        $this->db->select('n.*');
        $this->db->from('network AS n');
        $this->db->where('n.upline', $upline);
        return $this->db->get()->result_array();
    }
    public function getPaket($member)
    {
        $this->db->select('n.*');
        $this->db->from('network AS n');
        $this->db->where('n.member_id', $member);
        return $this->db->get()->result_array();
    }

    public function get_kolom($memberId)
    {
        $this->db->select('n.*, p.nama as nama_paket, m.nama as nama_member');
        $this->db->from('network AS n');
        $this->db->join('paket as p', 'n.paket = p.paket_id');
        $this->db->join('member AS m', 'n.member_id = m.member_id');
        $this->db->where('n.upline', $memberId);
        $this->db->order_by('n.posisi', 'DESC');
        return $this->db->get()->result_array();
    }

    public function getMembers()
    {
        $this->db->select('n.*');
        $this->db->from('network AS n');
        return $this->db->get()->result_array();
    }
    public function markBonusReceived($memberId)
    {
        $this->db->set('bonus_count', 'bonus_count + 1', false);
        $this->db->where('member_id', $memberId);
        $this->db->update('network');
    }

    public function count_pendaftaran()
    {
        $silver = $this->db->where('paket', 'n2NEePzD6cjti86Aki')->count_all_results('network');
        $gold = $this->db->where('paket', 'AUmpTd0eiDiySMkyiR')->count_all_results('network');
        $platinum = $this->db->where('paket', 'ghuSXbKMduS3LMz2Ve')->count_all_results('network');

        return array('silver' => $silver, 'gold' => $gold, 'platinum' => $platinum);
    }

    public function get_status_reward($memberId)
    {
        $this->db->select('status_reward');
        $this->db->from('network');
        $this->db->where('member_id', $memberId);
        return $this->db->get()->row_array();
    }

    public function tambah_total_downline($upline, $posisi, $poin)
    {
        if ($posisi == 'Kiri') {
            $this->db->set('point_pasangan_kiri', 'total_kiri +' . $poin, false);
        } else {
            $this->db->set('point_pasangan_kanan', 'total_kanan +' . $poin, false);
        }
        $this->db->where('member_id', $upline);
        $this->db->update('network');
    }

    public function update_point_pasangan($member_id, $poin)
    {
        $this->db->set('point_pasangan', $poin, false);
        $this->db->where('member_id', $member_id);
        $this->db->update('network');
    }

    public function getMembersByDate()
    {
        $data = $this->db->select('n.*')
            ->from('network AS n')
            //->where("n.data_created LIKE '2024-01-07%'")
            //->where("n.posisi", "Kanan")
            ->order_by('data_created', 'desc')
            ->get()->result_array();
        //var_dump($data);
        echo "<pre>";
        echo print_r($data);
        echo "</pre>";
        foreach ($data as $row) {
            
            if ($row['paket'] == "AUmpTd0eiDiySMkyiR") {
                $poinData = 3;
            } elseif ($row['paket'] == "n2NEePzD6cjti86Aki") {
                $poinData = 1;
            } else {
                $poinData = 5;
            }

            $upline = $row['upline'];
            $posisi = $row['posisi'];

            if ($posisi == 'Kiri') {

                $ki = $row['point_pasangan_kiri'] + $row['point_pasangan_kanan'];
                $kiri = $ki + $poinData;
                $this->db->set('point_pasangan_kiri', $kiri, false);
                //echo "ki " .  $ki . " kiri " . $kiri." <br/>";
            } else{
                $ka = $row['point_pasangan_kiri'] + $row['point_pasangan_kanan'];
                $kanan = $ka+ $poinData;
                $this->db->set('point_pasangan_kanan', $kanan, false);
                //echo "ka " . $ka . "kanan " .  $kanan ." <br/>";
            }
            
            $this->db->where('member_id', $upline);
            $this->db->update('network');

            //echo $row['member_id'] ." -> ".  $row['posisi'] ." -> ". $row['point_pasangan_kiri'] . " | ". $row['point_pasangan_kanan'] ."</br>";
                //var_dump($poinData);

        }

    }
}
