<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Profil_model extends CI_Model
{
  public function getProfil($id = null)
  {
    if ($id !== null) {
      $this->db->get('profil');
      $this->db->where('member_id', $id);
      return $this->db->get()->row_array();
    }
    return $this->db->get('profil')->row_array();
  }

  public function store($data) {
    $this->db->insert('profil', $data);
    return $this->db->insert_id();
  }
}