<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Member_model extends CI_Model
{
    public function get_data()
    {

        $this->db->select('n.*, m.nama AS member_name, m.username AS member_username, m.kloning as member_kloning, m.kloning_id as kloning_id, m.is_active as member_is_active, s.member_id AS sponsor_id, s.username AS sponsor_username, s.nama AS sponsor_name, u.member_id AS upline_id, u.username AS upline_username, u.nama AS upline_name, p.nama AS paket_name');
        $this->db->from('network as n');
        $this->db->join('member as m', 'n.member_id = m.member_id', 'left');
        $this->db->join('member as s', 'n.sponsor = s.member_id', 'left');
        $this->db->join('member as u', 'n.upline = u.member_id', 'left');
        $this->db->join('paket as p', 'n.paket = p.paket_id', 'left');
        $this->db->order_by('n.data_created');

        $hasil = $this->db->get();
        return $hasil->result();
    }

    public function get_role($member_id)
    {
        $this->db->select('role_id');
        $this->db->from('member');
        $this->db->where('member_id', $member_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function isEmpty($member_id)
    {
        $this->db->select('posisi');
        $this->db->from('network');
        $this->db->where('upline', $member_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_pv($member_id)
    {
        $this->db->select('pv');
        $this->db->from('member');
        $this->db->where('member_id', $member_id);

        $pv = $this->db->get();
        return $pv->row_array();
    }

    public function get_paket($id_member)
    {
        $this->db->select('p.nama');
        $this->db->join('paket as p', 'n.paket = p.paket_id');
        $this->db->from('network as n');
        $this->db->where('n.member_id', $id_member);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_data_prospek()
    {
        $this->db->select('n.*,
                   m.nama AS member_name,
                   m.username AS member_username,
                   m.kloning as member_kloning,
                   m.kloning_id as kloning_id,
                   m.is_active as member_is_active,
                   f.no_identitas as no_identitas,
                   p.nama AS paket_name');
        $this->db->from('network as n');
        $this->db->where('sponsor', $this->session->userdata('member_id'));
        $this->db->join('member as m', 'n.member_id = m.member_id', 'left');
        $this->db->join('member as s', 'n.sponsor = s.member_id', 'left');
        $this->db->join('profil as f', 'f.member_id = m.member_id', 'left');
        $this->db->join('paket as p', 'n.paket = p.paket_id', 'left');
        $this->db->order_by('n.data_created');

        $hasil = $this->db->get();
        return $hasil->result();
    }

    public function update_approval($member_id)
    {
        $data = [
            'is_active' => 1,
        ];
        $this->db->where('member_id', $member_id);
        $this->db->update('member', $data);
    }

    public function get_password($member_id)
    {
        $this->db->select('password');
        $this->db->from('member');
        $this->db->where('member_id', $member_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_member_by_id($id)
    {
        $this->db->select('m.*, mr.role');
        $this->db->from('member as m');
        $this->db->join('member_role as mr', 'mr.id_role = m.role_id');
        $this->db->where('m.member_id', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_data_by_id($id)
    {
        $this->db->select('n.*, m.nama as member_name, m.password as member_password, m.username as member_username, s.member_id as sponsor_id, s.username as sponsor_username, m.is_active as member_is_active, s.nama as sponsor_name, u.member_id as upline_id, u.username as upline_username, u.nama as upline_name, p.nama as paket_name, m.email');
        $this->db->from('network AS n');
        $this->db->join('member AS m', 'n.member_id = m.member_id', 'left');
        $this->db->join('member AS s', 'n.sponsor = s.member_id', 'left');
        $this->db->join('member AS u', 'n.upline = u.member_id', 'left');
        $this->db->join('paket AS p', 'n.paket = p.paket_id', 'left');
        $this->db->where('m.member_id', $id);
        $this->db->order_by('n.data_created');

        $hasil = $this->db->get();
        return $hasil->row_array();
    }

    public function store($data)
    {
        $this->db->insert('member', $data);
        return $this->db->insert_id();
    }

    public function findSponsorChain($member_id, $current_level = 1, $max_levels = 5)
    {
        if ($current_level > $max_levels) {
            return array();
        }

        $this->db->select('a.member_id, m.nama, a.sponsor');
        $this->db->from('network AS a');
        $this->db->join('member AS m', 'm.member_id = a.member_id');
        $this->db->where('a.member_id', $member_id);

        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $sponsor_id = $result['sponsor'];

            $result['sponsor_chain'] = $this->findSponsorChain($sponsor_id, $current_level + 1, $max_levels);

            return $result;
        }

        return array();
    }

    public function transfer_pv_stokis($member_id, $penerima_id, $pv)
    {
        $data = [
            'id_pv' => uniqid(),
            'penerima' => $penerima_id,
            'pengirim_id' => $member_id,
            'jumlah_pv' => $pv,
        ];

        $this->db->insert('pv_transaction', $data);

        $this->db->set('pv', 'pv + ' . $pv, false);
        $this->db->where('member_id', $penerima_id);
        $this->db->update('member');
    }

    public function transfer_pv($member_id, $penerima_id, $pv)
    {
        $data = [
            'id_pv' => uniqid(),
            'penerima' => $penerima_id,
            'pengirim_id' => $member_id,
            'jumlah_pv' => $pv,
        ];

        $this->db->insert('pv_transaction', $data);

        $this->db->set('pv', 'pv - ' . $pv, false);
        $this->db->where('member_id', $member_id);
        $this->db->update('member');

        $this->db->set('pv', 'pv + ' . $pv, false);
        $this->db->where('member_id', $penerima_id);
        $this->db->update('member');
    }

    public function potong_pv($member_id, $paket)
    {
        switch ($paket) {
            case 'AUmpTd0eiDiySMkyiR':
                $pv = 300;
                break;
            case 'ghuSXbKMduS3LMz2Ve':
                $pv = 500;
                break;
            case 'n2NEePzD6cjti86Aki':
                $pv = 100;
                break;
        }
        $this->db->set('pv', 'pv -' . $pv, false);
        $this->db->where('member_id', $this->session->userdata('member_id'));
        $this->db->update('member');
    }

    public function update_profil($data, $id)
    {
        $this->db->where('member_id', $id);
        $this->db->update('profil', $data);
    }
    public function update_member($data, $id)
    {
        $this->db->where('member_id', $id);
        $this->db->update('member', $data);
    }

    public function update_password($id, $password) {
        $this->db->set('password', $password);
        $this->db->where('member_id', $id);
        $this->db->update('member');
    }

    public function potong_hu($member_id, $jumlah)
    {
        $this->db->set('kloning', 'kloning -' . $jumlah, false);
        $this->db->where('member_id', $this->session->userdata('member_id'));
        $this->db->update('member');
    }

    public function input_profil($data)
    {
        $this->db->insert('profil', $data);
    }
}
