<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Test_model extends CI_Model {
  protected $members;

  public function __construct() {
  }

  public function calculatePointsComparison($memberId) {
      // Hitung perbandingan poin dengan memanggil fungsi rekursif
      $pointsComparison = $this->calculateComparisonRecursively($memberId);

      return $pointsComparison;
  }

  protected function calculateComparisonRecursively($currentMember) {
      // Base case: jika member tidak memiliki kaki kiri dan kaki kanan
      if ($currentMember === null || !isset($this->members[$currentMember])) {
          return ['left' => 0, 'right' => 0];
      }

      // Hitung perbandingan poin dari kaki kiri dan kaki kanan
      $leftComparison = $this->calculateComparisonRecursively($this->members[$currentMember]['left']);
      $rightComparison = $this->calculateComparisonRecursively($this->members[$currentMember]['right']);

      // Akumulasi perbandingan poin dari kaki kiri, kaki kanan, dan member saat ini
      $totalComparison = [
          'left' => $leftComparison['left'] + $rightComparison['left'] + $this->getMemberPoints($this->members[$currentMember]['left']),
          'right' => $leftComparison['right'] + $rightComparison['right'] + $this->getMemberPoints($this->members[$currentMember]['right']),
      ];

      return $totalComparison;
  }

  protected function getMemberPoints($memberId) {
      // Implementasikan logika untuk mendapatkan poin dari member tertentu
      // Misalnya, jika poin ditentukan dalam suatu tabel database, lakukan query ke database
      // dan ambil poin berdasarkan $memberId

      // Contoh sederhana, mengembalikan nilai tetap 10 poin untuk setiap member
      return 10;
  }
}
