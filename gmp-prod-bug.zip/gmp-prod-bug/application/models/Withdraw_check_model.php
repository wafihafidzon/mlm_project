<?php

class Withdraw_check_model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = $this->db->get('detail_wallet')->result_array();

    foreach ($data as $value) {
      $this->db->set('amount', 'amount + ' . $value['amount'], false);
      $this->db->where('wallet_id', $value['wallet_id']);
      $this->db->update('wallet');
    }
  }
}