<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Bank_model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
  }

  public function getBank()
  {
    return $this->db->get('bank')->result_array();
  }

  public function update_status($bank_id, $status)
  {
    $this->db->set('status', $status);
    $this->db->where('bank_id', $bank_id);
    $this->db->update('bank');
  }

  public function get_bank_active()
  {
    $this->db->where('status', 1);
    return $this->db->get('bank')->result_array();
  }
}