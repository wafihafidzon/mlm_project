<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Withdraw_model extends CI_Model
{
    public function get_data_withdraw()
    {
        $this->db->select('w.*, m.nama');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->join('profil as p', 'p.member_id = m.member_id');
        $this->db->from('wallet as w');
        $this->db->where('w.updated_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)');
        $this->db->where('w.amount >=', 100000);
        $this->db->where('p.bank !=', 'NO BANK');
        return $this->db->get()->result_array();

    }

    public function get_data_withdraw_by_id($id)
    {
        $this->db->select('w.*, p.bank, p.rekening, p.nama_rekening');
        $this->db->join('profil as p', 'p.member_id = w.member_id');
        $this->db->from('withdraw_detail as w');
        $this->db->where('w.id_withdraw', $id);
        $this->db->where('w.status !=', 'rejected');
        return $this->db->get()->result_array();
    }

    public function get_withdraw()
    {
        return $this->db->get('withdraw')->result_array();
    }

    public function reject_amount($id_withraw_detail)
    {
        $data = $this->db->get_where('withdraw_detail', ['id_withdraw_detail' => $id_withraw_detail])->row_array();

        $this->db->set('amount', 'amount - ' . $data['amount'], false);
        $this->db->set('potongan_admin', 'potongan_admin - ' . $data['potongan_admin'], false);
        $this->db->set('potongan_sedekah', 'potongan_sedekah - ' . $data['potongan_sedekah'], false);
        $this->db->set('biaya_transfer', 'biaya_transfer - ' . $data['biaya_transfer'], false);
        $this->db->set('total_transfer', 'total_transfer - ' . $data['total_transfer'], false);
        $this->db->where('id_withdraw', $data['id_withdraw']);
        $this->db->update('withdraw');

        $this->db->set('amount', 'amount + ' . $data['amount'], false);
        $this->db->where('member_id', $data['member_id']);
        $this->db->update('wallet');

        $this->db->set('status', 'rejected');
        $this->db->where('id_withdraw_detail', $id_withraw_detail);
        $this->db->update('withdraw_detail');

    }

    public function isRejected($id)
    {
        $this->db->select('w.amount as withdraw, wa.amount, w.member_id, w.id_withdraw_detail');
        $this->db->join('wallet as wa', 'wa.member_id = w.member_id');
        $this->db->from('withdraw_detail as w');

        $this->db->where('w.id_withdraw_detail', $id);
        return $this->db->get()->result_array();
    }

    public function rubah_status($aksi, $id)
    {
        $this->db->set('status', $aksi);
        $this->db->where('id_withdraw_detail', $id);
        $this->db->update('withdraw_detail');

        $data = $this->db->get_where('withdraw_detail', ['id_withdraw_detail' => $id])->row_array();
        return $data;
    }

    public function insertWithdrawDetail($id_withdraw, $member_id, $amount, $potongan_admin, $potongan_sedekah, $potongan_transfer, $total_transfer)
    {
        $data_withdraw = [
            'id_withdraw' => $id_withdraw,
            'amount' => $amount,
            'potongan_admin' => $potongan_admin,
            'potongan_sedekah' => $potongan_sedekah,
            'biaya_transfer' => $potongan_transfer,
            'total_transfer' => $total_transfer,
        ];

        $this->db->set('amount', 'amount - ' . $amount, false);
        $this->db->where('member_id', $member_id);
        $this->db->update('wallet');

        $withdraw = $this->db->get_where('withdraw', array('id_withdraw' => $id_withdraw));
        if ($withdraw->num_rows() > 0) {
            $this->db->set('amount', 'amount + ' . $amount, false);
            $this->db->set('potongan_admin', 'potongan_admin + ' . $potongan_admin, false);
            $this->db->set('potongan_sedekah', 'potongan_sedekah + ' . $potongan_sedekah, false);
            $this->db->set('biaya_transfer', 'biaya_transfer + ' . $potongan_transfer, false);
            $this->db->set('total_transfer', 'total_transfer + ' . $total_transfer, false);
            $this->db->where('id_withdraw', $id_withdraw);
            $this->db->update('withdraw');

        } else {
            $this->db->insert('withdraw', $data_withdraw);
        }

        $data_detail_withdraw = [
            'id_withdraw_detail' => uniqid(),
            'id_withdraw' => $id_withdraw,
            'member_id' => $member_id,
            'amount' => $amount,
            'potongan_admin' => $potongan_admin,
            'potongan_sedekah' => $potongan_sedekah,
            'biaya_transfer' => $potongan_transfer,
            'total_transfer' => $total_transfer,
        ];

        $this->db->insert('withdraw_detail', $data_detail_withdraw);
    }

    public function sum_transferred()
    {
        $this->db->select_sum('total_transfer');
        $this->db->where('status =', 'Transferred');
        return $this->db->get('withdraw_detail')->row_array();
    }
    public function sum_pending()
    {
        $this->db->select_sum('total_transfer');
        $this->db->where('status =', 'Pending');
        return $this->db->get('withdraw_detail')->row_array();
    }

    public function sum_sedekah()
    {
        $this->db->select_sum('potongan_sedekah');
        $this->db->from('withdraw');
        $query = $this->db->get();
        return $query->row_array();
    }
}
