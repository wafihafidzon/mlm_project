<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Logs_model extends CI_Model{
    public function add_log($log){
        $logs =[
            'id_logs'       => uniqid(),
            'logs'          => $log,
            'member_id'     => $this->session->userdata('member_id'),
            'data_created'  => date("Y-m-d H:i:s")
        ];
        $this->db->insert('logs', $logs);
    }

    public function logout(){
        $logs =[
            'id_logs'       => uniqid(),
            'logs'          => "berhasil keluar dari sistem",
            'member_id'     => $this->session->userdata('member_id'),
            'data_created'  => date("Y-m-d H:i:s")
        ];
        $this->db->insert('logs', $logs);
        
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('role_id');
		$this->session->unset_userdata('member_id');

		$this->session->set_flashdata('message', 'berhasil.Anda berhasil keluar!');
		redirect('masuk');
    }

    public function getLogs(){
        //SELECT id_logs,logs, member.nama, logs.data_created FROM logs INNER JOIN member ON member.member_id=logs.member_id;
        $this->db->select('id_logs,logs, member.nama, logs.data_created');        
		$this->db->join('member', 'member.member_id=logs.member_id');
        $hasil = $this->db->get('logs'); 
        return $hasil->result(); 
    }
    
    public function getLogsBy($id){
        //SELECT id_logs,logs, member.nama, logs.data_created FROM logs INNER JOIN member ON member.member_id=logs.member_id;
        $this->db->select('id_logs,logs, member.nama, logs.data_created');        
		$this->db->join('member', 'member.member_id=logs.member_id');
		$this->db->where('logs.member_id', $id);
        $hasil = $this->db->get('logs'); 
        return $hasil->result(); 
    }
}