<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Paket_model extends CI_Model
{
  public function getPaket($id = null)
  {
    if ($id === null) {
      return $this->db->get('paket')->result_array();
    } else {
      return $this->db->get_where('paket', ['id' => $id])->row_array();
    }
  }
}