<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
* GMP - PT Geo Mulia Perkasa
*/
class Pv_model extends CI_Model
{
  public function get_pv()
  {
    $query = $this->db->get('pv_transaction');
    return $query->result_array();
  }
  public function get_pv_by_id($member_id)
  {
    $this->db->select('*');
    $this->db->where('pengirim_id', $member_id);
    $this->db->or_where('penerima', $member_id);
    $this->db->from('pv_transaction');
    $query = $this->db->get();
    return $query->result_array();
  }
}