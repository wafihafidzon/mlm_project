<?php defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

/*
 * GMP - PT Geo Mulia Perkasa
 */
class Wallet_model extends CI_Model
{
    public function get_wallet()
    {
        $this->db->select('wallet.*, member.nama');
        $this->db->join('member', 'wallet.member_id = member.member_id');
        $this->db->join('profil', 'member.member_id = profil.member_id');
        $this->db->from('wallet');
        $this->db->where('profil.bank =', 'NO BANK');
        return $this->db->get()->result();
    }

    public function get_detail_wallet($member_id)
    {
        $this->db->select('d.*');
        $this->db->join('wallet', 'd.wallet_id = wallet.wallet_id');
        $this->db->from('detail_wallet as d');
        $this->db->where('wallet.member_id', $member_id);
        return $this->db->get()->result();
    }

    public function get_data_withdraw()
    {
        $this->db->select('w.*, m.nama');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->from('wallet as w');
        $this->db->where('w.amount >=', 100000);
        return $this->db->get()->result_array();
    }

    public function get_data_withdraw_by_id($member_id)
    {
        $this->db->select('w.*, m.nama, p.bank, p.rekening, p.nama_rekening');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->join('profil as p', 'm.member_id = p.member_id');
        $this->db->from('wallet as w');
        $this->db->where('w.member_id', $member_id);
        return $this->db->get()->row_array();
    }

    public function add_bonus_sponsor($wallet, $member_id)
    {
        $query = $this->db->get_where('wallet', array('member_id' => $wallet['member_id']));
        $cek_wallet = $query->row_array();
        if ($cek_wallet != null) {
            $this->db->update('wallet');
            $this->db->join('member as m', 'wallet.member_id = m.member_id');
            $this->db->set('wallet.amount', 'wallet.amount + ' . $wallet['amount'], false);
            $this->db->where('wallet.member_id', $wallet['member_id']);
            $this->db->where('m.is_pin_kosong !=', 0);
        } else {
            $this->db->insert('wallet', $wallet);
        }

        $detail_wallet = [
            'detail_wallet_id' => uniqid(),
            'wallet_id' => @$cek_wallet['wallet_id'] != null ? @$cek_wallet['wallet_id'] : @$wallet['wallet_id'],
            'sumber' => 'Bonus Sponsor',
            'status' => 'Success',
            'amount' => $wallet['amount'],
            'keterangan' => $member_id,
        ];

        $this->db->insert('detail_wallet', $detail_wallet);
    }

    public function get_data_bonus_sponsor()
    {
        $this->db->select('d.*, w.wallet_id, w.member_id, m.nama');
        $this->db->from('detail_wallet as d');
        $this->db->join('wallet as w', 'd.wallet_id = w.wallet_id');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->where('sumber', 'Bonus Sponsor');
        $this->db->order_by('d.created_at');

        return $this->db->get()->result();
    }
    public function get_data_bonus_sponsor_by_id()
    {
        $this->db->select('d.*, w.wallet_id, w.member_id, m.nama');
        $this->db->from('detail_wallet as d');
        $this->db->join('wallet as w', 'd.wallet_id = w.wallet_id');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->where('sumber', 'Bonus Sponsor');
        $this->db->where('w.member_id', $this->session->userdata('member_id'));
        $this->db->order_by('d.created_at');

        return $this->db->get()->result();
    }

    public function get_data_bonus_pasangan()
    {
        $this->db->select('d.*, w.wallet_id, w.member_id, m.nama');
        $this->db->from('detail_wallet as d');
        $this->db->join('wallet as w', 'd.wallet_id = w.wallet_id');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->where('sumber', 'Bonus Pasangan');
        $this->db->order_by('d.created_at');

        return $this->db->get()->result();
    }
    public function get_data_bonus_pasangan_by_id()
    {
        $this->db->select('d.*, w.wallet_id, w.member_id, m.nama');
        $this->db->from('detail_wallet as d');
        $this->db->join('wallet as w', 'd.wallet_id = w.wallet_id');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->where('sumber', 'Bonus Pasangan');
        $this->db->where('w.member_id', $this->session->userdata('member_id'));
        $this->db->order_by('d.created_at');

        return $this->db->get()->result();
    }

    public function get_data_bonus_titik()
    {
        $this->db->select('d.*, w.wallet_id, w.member_id, m.nama');
        $this->db->from('detail_wallet as d');
        $this->db->join('wallet as w', 'd.wallet_id = w.wallet_id');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->where('sumber', 'Bonus Titik');
        $this->db->order_by('d.created_at');

        return $this->db->get()->result();
    }

    public function get_data_bonus_titik_by_id()
    {
        $this->db->select('d.*, w.wallet_id, w.member_id, m.nama');
        $this->db->from('detail_wallet as d');
        $this->db->join('wallet as w', 'd.wallet_id = w.wallet_id');
        $this->db->join('member as m', 'w.member_id = m.member_id');
        $this->db->where('sumber', 'Bonus Titik');
        $this->db->where('w.member_id', $this->session->userdata('member_id'));
        $this->db->order_by('d.created_at');

        return $this->db->get()->result();
    }

    public function get_sum_bonus_sponsor()
    {
        $this->db->select_sum('amount');
        $this->db->from('detail_wallet');
        $this->db->where('sumber', 'Bonus Sponsor');

        return $this->db->get()->row_array();
    }

    public function get_sum_bonus_sponsor_by_id()
    {
        $this->db->select_sum('detail_wallet.amount');
        $this->db->join('wallet', 'wallet.wallet_id = detail_wallet.wallet_id');
        $this->db->from('detail_wallet');
        $this->db->where('detail_wallet.sumber', 'Bonus Sponsor');
        $this->db->where('wallet.member_id', $this->session->userdata('member_id'));

        return $this->db->get()->row_array();
    }

    public function get_sum_bonus_titik()
    {
        $this->db->select_sum('amount');
        $this->db->from('detail_wallet');
        $this->db->where('sumber', 'Bonus Titik');

        return $this->db->get()->row_array();
    }

    public function get_sum_bonus_titik_by_id()
    {
        $this->db->select_sum('detail_wallet.amount');
        $this->db->join('wallet', 'wallet.wallet_id = detail_wallet.wallet_id');
        $this->db->from('detail_wallet');
        $this->db->where('detail_wallet.sumber', 'Bonus Titik');
        $this->db->where('wallet.member_id', $this->session->userdata('member_id'));

        return $this->db->get()->row_array();
    }

    public function get_sum_bonus_pasangan()
    {
        $this->db->select_sum('amount');
        $this->db->from('detail_wallet');
        $this->db->where('sumber', 'Bonus Pasangan');

        return $this->db->get()->row_array();
    }

    public function get_sum_bonus_pasangan_by_id()
    {
        $this->db->select_sum('detail_wallet.amount');
        $this->db->join('wallet', 'wallet.wallet_id = detail_wallet.wallet_id');
        $this->db->from('detail_wallet');
        $this->db->where('detail_wallet.sumber', 'Bonus Pasangan');
        $this->db->where('wallet.member_id', $this->session->userdata('member_id'));

        return $this->db->get()->row_array();
    }

    public function addToAdminWallet($adminWallet)
    {

        $this->db->set('amount', 'amount + ' . $adminWallet, false);
        $this->db->where('member_id', 'wallet_admin');
        $this->db->update('wallet');

        $detail_wallet = [
            'detail_wallet_id' => uniqid(),
            'wallet_id' => 'D37OS35KPY0IAE4P392Y',
            'sumber' => 'Bonus Pasangan',
            'status' => 'Success',
            'amount' => $adminWallet,
            'keterangan' => 'Flush',
        ];

        $this->db->insert('detail_wallet', $detail_wallet);
    }

    public function addBonusPasangan($memberId, $amount, $point_reedem)
    {
        $wallet = [
            'wallet_id' => uniqid(),
            'member_id' => $memberId,
            'amount' => $amount,
        ];

        $query = $this->db->get_where('wallet', array('member_id' => $memberId));
        $cek_wallet = $query->row_array();
        if ($cek_wallet != null) {
            $this->db->join('member as m', 'wallet.member_id = m.member_id');
            $this->db->set('wallet.amount', 'wallet.amount + ' . $wallet['amount'], false);
            $this->db->where('wallet.member_id', $wallet['member_id']);
            $this->db->update('wallet');
        } else {
            $this->db->insert('wallet', $wallet);
        }

        $detail_wallet = [
            'detail_wallet_id' => uniqid(),
            'wallet_id' => @$cek_wallet['wallet_id'] != null ? @$cek_wallet['wallet_id'] : @$wallet['wallet_id'],
            'sumber' => 'Bonus Pasangan',
            'status' => 'Success',
            'amount' => $amount,
            'keterangan' => $point_reedem,
        ];

        $this->db->insert('detail_wallet', $detail_wallet);
    }

    public function saveBonusToWallet($member_id, $bonus_amount)
    {
        $wallet = [
            'wallet_id' => uniqid(),
            'member_id' => $member_id,
            'amount' => $bonus_amount,
        ];

        $query = $this->db->get_where('wallet', array('member_id' => $member_id));
        $cek_wallet = $query->row_array();

        if ($cek_wallet != null) {
            // Gunakan += untuk menambahkan bonus ke amount
            $this->db->set('amount', 'amount + ' . $bonus_amount, false);
            $this->db->where('member_id', $member_id);
            $this->db->update('wallet');
        } else {
            $this->db->insert('wallet', $wallet);
        }

        // Tentukan wallet_id untuk detail_wallet
        $wallet_id = isset($cek_wallet['wallet_id']) ? $cek_wallet['wallet_id'] : $wallet['wallet_id'];

        $detail_wallet = [
            'detail_wallet_id' => uniqid(),
            'wallet_id' => $wallet_id,
            'sumber' => 'Bonus Titik',
            'status' => 'Success',
            'amount' => $bonus_amount,
            'keterangan' => 'Bonus Titik',
        ];

        $this->db->insert('detail_wallet', $detail_wallet);
    }

    public function insert_withdraw($member_id, $amount, $data)
    {
        $this->db->set('amount', 'amount - ' . $amount, false);
        $this->db->where('member_id', $member_id);
        $this->db->update('wallet');

        $this->db->set('amount', 'amount + ' . $data['total_potongan'], false);
        $this->db->where('member_id', 'wallet_admin');
        $this->db->update('wallet');

        $wallet_id = $this->db->get_where('wallet', array('member_id' => $member_id))->row_array()['wallet_id'];

        $detail_wallet_withdraw_member = [
            'detail_wallet_id' => uniqid(),
            'wallet_id' => $wallet_id,
            'sumber' => 'Withdraw',
            'status' => 'Success',
            'amount' => $amount,
            'keterangan' => 'Withdraw',
        ];

        $this->db->insert('detail_wallet', $detail_wallet_withdraw_member);

        $detail_wallet_potongan = [
            'detail_wallet_id' => uniqid(),
            'wallet_id' => $wallet_id,
            'sumber' => 'Potongan Admin',
            'status' => 'Success',
            'amount' => $data['potongan_admin'],
            'keterangan' => 'Withdraw',
        ];
    }

    public function get_wallet_pendapatan()
    {
        $this->db->select('wallet.member_id, wallet.amount, profil.bank');
        $this->db->join('profil', 'profil.member_id = wallet.member_id');
        $this->db->from('wallet');
        $this->db->where('wallet.amount < ', 100000);
        $this->db->where('wallet.amount >= ', 1);
        $this->db->or_where('profil.bank =', 'NO BANK');
        $query = $this->db->get();
        return $query->result_array();
    }

}
