<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="<?= base_url('add_member') ?>" method="post">
  <input type="text" name="username">
  <button type="submit">asd</button>
<?php
  $prefix = 'GMPS-';
  $uniqueId = $prefix . strtoupper(substr(uniqid(),6,13));

echo "Unique ID: $uniqueId";
?>
</form>
</body>
</html>