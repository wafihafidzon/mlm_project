<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
  .table td[rowspan] {
    vertical-align: middle;
    text-align: center;
  }

  .table {
    text-align: center;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?=$title;?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="card col-md-10">
            <div class="card card-header">
              <h3>Prospek Member</h3>
              <?=var_dump($this->session->userdata('member_id'))?>
              <?=var_dump($member)?>
            </div>
            <div class="row">
              <div class="col-md-4">
                <div class="" style="display: flex; margin:15px gap: 5px;">
                  <div class="card">
                    <div class="form-check" style="margin:14px; padding:5px; margin-right: 10px">
                      <input class="form-check-input" type="radio" name="flexRadioDefault" value="new" checked>
                      <label class="form-check-label" for="flexRadioDefault1">
                        New
                      </label>
                    </div>
                  </div>
                  <div class="card" style="margin-left: 15px;">
                    <div class="form-check" style="margin:14px; padding:5px;">
                      <input class="form-check-input" type="radio" name="flexRadioDefault" value="kloning">
                      <label class="form-check-label" for="flexRadioDefault1">
                        Kloning
                      </label>
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Data Prospek Member</h3>
                  </div>
                  <form method="post" action="<?=base_url('insert_member')?>">
                    <div class="card-body">
                      <div class="form-group">
                        <label>Nomer HP</label>
                        <input type="text" class="form-control" name="no_hp">
                      </div>
                      <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" name="username">
                      </div>
                      <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap">
                      </div>
                      <div class="form-group">
                        <label>No. KTP</label>
                        <input type="number" class="form-control" name="ktp">
                      </div>
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select class="form-control" name="jenis_kelamin">
                          <option value="L">Laki-laki</option>
                          <option value="P">Perempuan</option>
                        </select>
                      </div>
                    </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Data Bank</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Bank</label>
                      <input type="text" class="form-control" name="bank">
                    </div>
                    <div class="form-group">
                      <label>Nomer Rekening</label>
                      <input type="text" class="form-control" name="no_rekening">
                    </div>
                    <div class="form-group">
                      <label>Nama Nasabah</label>
                      <input type="text" class="form-control" name="nama_nasabah">
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Data Jaringan</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <div style="display: flex; justify-content: space-between">
                        <label>Sponsor</label>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="" id="saya_adalah_sponsor">
                          <label class="form-check-label" for="flexCheckDefault">
                            Saya adalah sponsor
                          </label>
                        </div>
                      </div>
                      <input type="text" class="form-control" name="username_sponsor">
                      <label id="nama_member">Nama Member :
                        <?=$member['member_name']?>
                      </label>
                    </div>
                    <div class="form-group">
                      <label>Opsi Jaringan</label>
                      <select class="form-control" id="opsi_jaringan" name="opsi_jaringan">
                        <option value="Sponsor">Sponsor</option>
                        <option value="Upline">Upline</option>
                      </select>
                    </div>
                    <div class="form-group username_upline">
                      <label>Upline</label>
                      <input type="text" class="form-control" id="text_username_upline" name="username_upline">
                    </div>
                    <div class="mitra-sponsor">
                      <label>Posisi Mitra Sponsor</label>
                      <div class="form-check">
                        <input type="radio" class="form-check-input" value="Kiri" name="posisi">
                        <label>Kiri</label>
                      </div>
                      <div class="form-check">
                        <input type="radio" class="form-check-input" value="Kanan" name="posisi">
                        <label>Kanan</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Paket Pendaftaran</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Paket Pendaftaran</label>
                      <select class="form-control" name="paket_id">
                        <?php foreach ($paket as $p): ?>
                        <option value="<?=$p['paket_id']?>">
                          <?=$p['nama']?>
                        </option>
                        <?php endforeach;?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Hak Usaha</label>
                      <input type="number" class="form-control" name="hak_usaha">
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Akun</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Email</label>
                      <input type="text" class="form-control" name="email">
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input type="text" class="form-control" name="password">
                    </div>
                  </div>
                </div>
              </div>
            </div>


      <?php
$upline = $this->Network_model->getUpline('ED25WTAXMUESJLWVZ2');
var_dump($upline);
?>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-info">Submit</button>
          </div>
          </form>
        </div>
      </section>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>

    </script>


    <script>
    $(document).ready(function() {
      <?php
$upline = $this->Network_model->getUpline('ED25WTAXMUESJLWVZ2');
?>
      var uplineStatus = "<?=$upline[0]['side']?>";
      var upline = "<?=$member['member_id']?>";
      var noHp = "<?=$profil['wa']?>";
      var noIdentitas = "<?=$profil['no_identitas']?>";
      var nama = "<?=$profil['nama']?>";
      var username = "<?=$member['member_username']?>";

      console.log(uplineStatus);
      if (uplineStatus === upline) {

      }

      $('.username_upline').hide();
      $('#text_username_upline').val(upline);
      $('#nama_member').hide();

      $('input[name="flexRadioDefault"]').change(function() {
        // Periksa apakah yang dipilih adalah "Kloning"
        if ($(this).val() === 'kloning') {
          // Jika "Kloning" dipilih, isi input dari database dan buat tidak dapat diubah
          $('input[name="no_hp"]').val(noHp).prop('readonly', true);
          $('input[name="username"]').val(username).prop('readonly', true);
          $('input[name="nama_lengkap"]').val(nama).prop('readonly', true);
          $('input[name="ktp"]').val(noIdentitas).prop('readonly', true);
          $('#saya_adalah_sponsor').prop('checked', true).prop('disabled', true);
          $('#nama_member').show();
          $('input[name="username_sponsor"]').val(username).prop('readonly', true);
          $('select[name="opsi_jaringan"]').val('Sponsor').prop('disabled', true);
          $('.mitra-sponsor').hide();
        } else {
          // Jika "New" dipilih, kembalikan input ke kondisi normal
          $('input[name="no_hp"]').val('').prop('readonly', true);
          $('input[name="username"]').val('').prop('readonly', true);
          $('input[name="nama_lengkap"]').val('').prop('readonly', true);
          $('input[name="ktp"]').val('').prop('readonly', true);
          $('#saya_adalah_sponsor').prop('checked', false).prop('disabled', false);
          $('#nama_member').show();
          $('input[name="username_sponsor"]').val('').prop('readonly', true);
          $('select[name="opsi_jaringan"]').val('Sponsor').prop('disabled', true);
          $('.mitra-sponsor').show();
        }
      });


      $('#saya_adalah_sponsor').change(function() {
        if (this.checked) {
          $('input[name="username_sponsor"]').val(username).prop('readonly', true);
          $('#nama_member').show();
        } else {
          $('#nama_member').hide();
        }
      })

      $('#opsi_jaringan').change(function() {
        if ($(this).val() === 'Upline') {
          $('.username_upline').show().val(upline);
          $('#text_username_upline').val(upline);
          // console.log(upline);
        } else {
          console.log(upline);
          $('#text_username_upline').val(upline);
          $('.username_upline').hide();
        }
      });
    });
    </script>

    <?php //$this->load->view("_partials/footer.php")?>
    <?php //$this->load->view("_partials/js.php")?>
</body>

</html>