<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
  .table td[rowspan] {
    vertical-align: middle;
    text-align: center;
  }

  .table {
    text-align: center;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?=$title;?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="card col-md-12">
            <div class="card card-header">
              <h3>Detail Member</h3>
            </div>
            <div class="row">
              <div class="col-md-6">

                <div class="card card-primary m-3">
                  <?php
if ($this->session->flashdata('error')) {
    echo '<div class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
}
?>
                  <form method="post" action="<?=base_url('member/update_member')?>">
                    <div class="card-body">
                      <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" id="username" name="username"
                          value="<?= $member['member_username'] ?>" required>
                      </div>
                      <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" id="email" name="email"
                          value="<?= $member['email'] ?>" required>
                      </div>
                      <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap"
                          value="<?= $profil['nama'] ?>" required>
                      </div>
                      <div class="form-group">
                        <label>No. KTP</label>
                        <input type="number" class="form-control" id="ktp" name="ktp"
                          value="<?= $profil['no_identitas'] ?>" required>
                      </div>
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" id="cars" class="form-select">
                          <option <?php if($profil['gender'] == null) {echo "selected";} ?> hidden disabled>Select Jenis
                            Kelamin</option>
                          <?php ?>
                          <option value="Pria" <?php if($profil['gender'] == "Pria") {echo "selected";} ?>>Pria</option>
                          <option value="Wanita" <?php if($profil['gender'] == "Wanita") {echo "selected";} ?>>Wanita
                          </option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" class="form-control" id="tempatLahir" name="tempat_lahir"
                          value="<?= $profil['tmpt_lahir']?>">
                      </div>
                      <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" class="form-control" id="tglLahir" value="<?= $profil['tgl_lahir'] ?>"
                          name="tanggal_lahir">
                      </div>
                    </div>
                </div>

              </div>
              <div class="col-md-6">
                <div class="card card-primary m-3">
                  <div class="card-body">
                    <div class="form-group username_upline">
                      <label>Provinsi</label>
                      <input type="text" class="form-control" id="provinsi" name="provinsi"
                        value="<?= $profil['provinsi'] ?>" required>
                    </div>
                    <div class="form-group username_upline">
                      <label>Kota</label>
                      <input type="text" class="form-control" id="kota" name="kota" value="<?= $profil['kota'] ?>"
                        required>
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-body">
                    <div class="form-group">
                      <label>Bank</label>
                      <select class="form-control" name="bank">
                        <option value="" hidden selected>NO BANK</option>a
                        <?php foreach ($bank as $bank): ?>
                        <option value="<?=$bank['bank_id']?>" <?php if($profil['bank'] == $bank['bank_id']) {echo "selected";} ?>>
                          <?=$bank['nama']?>
                        </option>
                        <?php endforeach;?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Nama Pemilik Rekening</label>
                      <input type="text" class="form-control" name="no_rekening" id="nama_rekening" readonly
                        value="<?= $profil['nama'] ?>">
                    </div>
                    <div class="form-group">
                      <label>Nomer Rekening</label>
                      <input type="text" class="form-control" id="no_rekening" name="no_rekening"
                        value="<?= $profil['rekening'] ?>" required>
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-body">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                      Ganti Password
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Button trigger modal -->


          <!-- Modal -->
          <div class="card-footer">
            <button type="submit" id="submit" class="btn btn-info">Submit</button>
          </div>
        </form>
      </div>
    </section>
  </div>
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit Password</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?= base_url('member/update_password') ?>" method="post">
          <div class="modal-body">
            <div class="alert alert-danger" role="alert" id="passwordAlert">
              Password dengan konfirmasi password tidak sesuai
            </div>
            <div class="form-group">
              <label>Masukkan Password Lama</label>
              <input type="password" class="form-control" id="oldPassword" name="password_lama" required>
            </div>
            <div class="form-group">
              <label>Masukkan Password Baru</label>
              <input type="password" class="form-control" id="newPassword" name="new_password" required>
            </div>
            <div class="form-group">
              <label>Konfirmasi Ulang Password Baru</label>
              <input type="password" class="form-control" id="confirmPassword" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" id="passwordSubmit" class="btn btn-primary" disabled>Save changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>

    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');
    const passwordAlert = document.getElementById('passwordAlert');

    const passwordSubmit = document.getElementById('passwordSubmit');

    console.log(passwordAlert);
    passwordAlert.style.display = 'none';

    newPassword.addEventListener('keyup', function() {
      if (newPassword.value != confirmPassword.value) {
        passwordAlert.style.display = 'block'
        passwordSubmit.disabled = true
      } else {
        passwordAlert.style.display = 'none'
        passwordSubmit.disabled = false
      }
    })

    confirmPassword.addEventListener('keyup', function() {
      if (newPassword.value != confirmPassword.value) {
        passwordAlert.style.display = 'block'
        passwordSubmit.disabled = true
      } else {
        passwordAlert.style.display = 'none'
        passwordSubmit.disabled = false
      }
    })

    </script>
    <?php $this->load->view("_partials/footer.php")?>
    <?php $this->load->view("_partials/js.php")?>
</body>

</html>