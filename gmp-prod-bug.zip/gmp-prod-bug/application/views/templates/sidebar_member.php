<aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color:#1F6521;">
  <a href="<?=base_url();?>" class="brand-link">
    <img src="<?=base_url();?>assets/img/favicon.png" alt="<?=SITE_NAME;?> Logo"
      class="brand-image img-circle elevation-3" style="background-color:white;">
    <span class="brand-text font-weight-light"><?=SITE_NAME;?></span>
  </a>
  <div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <img src="<?=base_url();?>assets/img/profil/<?=$profil['foto_profil'];?>" class="img-circle elevation-2 "
          alt="<?=$profil['nama'];?>">
      </div>
      <div class="info">
        <a href="<?=base_url('profil');?>" class="d-block"><?=$profil['nama'];?></a>
        <a href="<?=base_url('profil');?>" class="d-block"></a>
      </div>
    </div>

    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a href="<?=base_url('memberview/dashboard');?>" class="nav-link">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Beranda</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <p>
              <i class="nav-icon fa-solid fa-user"></i>
              Member
              <i class="right fas fa-angle-down"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?=base_url('detail_member/' . $this->session->userdata('member_id'));?>" class="nav-link">
                <p>Data Member</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('admin/add_member');?>" class="nav-link">
                <p>Input Daftar Member</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <p>
            <i class="nav-icon fa-solid fa-database"></i>
              Transaksi PV
              <i class="right fas fa-angle-down"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?=base_url('memberView/transfer_pv')?>" class="nav-link">
                <p>Transfer PV</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <p>
              <i class="nav-icon fa-solid fa-user"></i>
              Laporan
              <i class="right fas fa-angle-down"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?=base_url('bonus-sponsor');?>" class="nav-link">
                <p>Bonus Sponsor</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('bonus-pasangan');?>" class="nav-link">
                <p>Bonus Pasangan</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('bonus-titik');?>" class="nav-link">
                <p>Bonus Titik</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <p>
              <i class="nav-icon fa-solid fa-user"></i>
              Bonus
              <i class="right fas fa-angle-down"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?=base_url('/wallet');?>" class="nav-link">
                <p>E-Wallet</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('admin/member/prospek');?>" class="nav-link">
                <p>Withdraw</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="<?=base_url('keluar');?>" class="nav-link">
            <i class="nav-icon fas fa-power-off text-danger"></i>
            <p class="text">Keluar</p>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</aside>