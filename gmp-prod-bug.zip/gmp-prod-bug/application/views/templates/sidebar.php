<aside class="main-sidebar sidebar-light-success elevation-4" style="background-color:#1F6521;">
  <a href="<?=base_url();?>" class="brand-link">
    <img src="<?=base_url();?>assets/img/favicon.png" alt="<?=SITE_NAME;?> Logo"
      class="brand-image img-circle elevation-3" style="background-color:white;">
    <span class="brand-text font-weight-light text-white"><?=SITE_NAME;?></span>
  </a>
  <div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <img src="<?=base_url();?>assets/img/profil/<?=$profil['foto_profil'];?>" class="img-circle elevation-2 "
          alt="<?=$profil['nama'];?>">
      </div>
      <div class="info">
        <a href="<?=base_url('profil');?>" class="d-block text-white"><?=$profil['nama'];?></a>
        <a href="<?=base_url('profil');?>" class="d-block text-white"></a>
      </div>
    </div>

    <nav class="mt-2 ">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a href="<?=base_url('/dashboard');?>" class="nav-link">
            <i class="nav-icon text-white fas fa-tachometer-alt"></i>
            <p class=" text-white">Beranda</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon text-white fas fa-user"></i>
            <p class=" text-white">
              Member
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3'){ ?>
            <li class="nav-item">
              <a href="<?=base_url('/member');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Data Member</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '5' || $this->session->userdata('role_id') == '4'){?>
            <li class="nav-item">
              <a href="<?=base_url('/detail_member/' . $this->session->userdata('member_id'));?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Data Member</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5'){?>
            <li class="nav-item">
              <a href="<?=base_url('/prospek');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Prospek Member</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3' ) {?>
            <li class="nav-item">
              <a href="<?=base_url('/add_member');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Input Daftar Member</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') {?>
            <li class="nav-item">
              <a href="<?=base_url('/memberview/add_member');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Input Daftar Member</p>
              </a>
            </li>
            <?php }?>
          </ul>
        </li>
        <?php if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') { ?>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon text-white fas fa-user"></i>
            <p class=" text-white">
              My Teams
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?=base_url('/network/index');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Upline Tree</p>
              </a>
            </li>
          </ul>
        </li>
        <?php } if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') {?>
        <li class="nav-item">
          <a href="<?=base_url('/bank'); ?>" class="nav-link">
            <i class="nav-icon text-white fas fa-user"></i>
            <p class=" text-white">
              Data Bank
            </p>
          </a>
        </li>
        <?php } ?>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon text-white fas fa-user"></i>
            <p class=" text-white">
              Transaksi PV
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') {?>
            <li class="nav-item">
              <a href="<?=base_url('/adminview/transfer_pv_stokis');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Transfer PV Stokis</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('/pv/log_pv');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Data Transaksi PV</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') { ?>
            <li class="nav-item">
              <a href="<?=base_url('/memberview/transfer_pv');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Transfer PV Member</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('/pv/log_pv_by_id');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class="text-white">Data Transaksi PV</p>
              </a>
            </li>
            <?php }?>
          </ul>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon text-white fas fa-user"></i>
            <p class=" text-white">
              Laporan
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') {?>
            <li class="nav-item">
              <a href="<?=base_url('adminview/pendapatan_perusahaan');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Income Perusahaan</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?=base_url('bonus-sponsor');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Bonus Sponsor</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') {?>
            <li class="nav-item">
              <a href="<?=base_url('bonus-sponsor/' . $this->session->userdata('member_id'));?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Bonus Sponsor</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') {?>
            <li class="nav-item">
              <a href="<?=base_url('bonus-pasangan/' . $this->session->userdata('member_id'));?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Bonus Pasangan</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') {?>
            <li class="nav-item">
              <a href="<?=base_url('bonus-pasangan');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Bonus Pasangan</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') {?>
            <li class="nav-item">
              <a href="<?=base_url('bonus-titik/' . $this->session->userdata('member_id'));?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Bonus Titik</p>
              </a>
            </li>
            <?php } if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') { ?>
            <li class="nav-item">
              <a href="<?=base_url('bonus-titik');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Bonus Titik</p>
              </a>
            </li>
            <?php }?>
          </ul>
        </li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon text-white fas fa-user"></i>
            <p class=" text-white">
              Bonus
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') { ?>
            <li class="nav-item">
              <a href="<?=base_url('/wallet');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Wallet</p>
              </a>
            </li>
            <?php } if ($this->session->userdata('role_id') == '2' || $this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') { ?>
            <li class="nav-item">
              <a href="<?=base_url('detail-wallet/') . $this->session->userdata('member_id') ;?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Wallet</p>
              </a>
              <?php } if($this->session->userdata('role_id') == '1' || $this->session->userdata('role_id') == '3') { ?>
            <li class="nav-item">
              <a href="<?=base_url('withdraw/withdraw');?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p class=" text-white">Withdraw</p>
              </a>
            </li>
            <?php } ?>
          </ul>
        </li>

        <li class="nav-item">
          <a href="<?=base_url('keluar');?>" class="nav-link">
            <i class="nav-icon fas fa-power-off text-danger"></i>
            <p class="text-white">Keluar</p>
          </a>
        </li>

      </ul>
    </nav>
  </div>
</aside>