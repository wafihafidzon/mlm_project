<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?= base_url();?>" class="brand-link">
        <img src="<?= base_url();?>assets/img/favicon.png" alt="<?=SITE_NAME;?> Logo" class="brand-image img-circle elevation-3" style="background-color:white;">
        <span class="brand-text font-weight-light"><?=SITE_NAME;?></span>
    </a>
    <div class="sidebar">    
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
            <img src="<?= base_url();?>assets/img/profil/<?= $profil['foto_profil'];?>" class="img-circle elevation-2 " alt="<?= $profil['nama'];?>">
            </div>
            <div class="info">
            <a href="<?= base_url('profil');?>" class="d-block"><?= $profil['nama'];?></a>
            <a href="<?= base_url('profil');?>" class="d-block"><?php if($this->session->userdata('role_id') == '1'){ echo "Administrator";}else{ echo "Pengguna";} ?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?= base_url('beranda');?>" class="nav-link active">
                    <i class="nav-icon fas fa-home text-blue"></i>
                    <p>Beranda</p>
                    </a>
                </li>
                <?php if($this->session->userdata('role_id') == '1'){ ?>
                <li class="nav-item">
                    <a href="<?= base_url('master');?>" class="nav-link">
                    <i class="nav-icon fas fa-cogs text-secondary"></i>
                    <p>Transaksi</p>
                    </a>
                </li>
                <?php } ?>
                <li class="nav-item">
                    <a href="<?= base_url('profil');?>" class="nav-link">
                    <i class="nav-icon fas fa-user text-success"></i>
                    <p>Profil</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('material');?>" class="nav-link">
                    <i class="nav-icon fas fa-folder-open text-cyan"></i>
                    <p>Materi</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('practice');?>" class="nav-link">
                    <i class="nav-icon fas fa-gamepad text-maroon"></i>
                    <p>Mari Berlatih</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('dongeng');?>" class="nav-link">
                    <i class="nav-icon fas fa-video text-yellow"></i>
                    <p>Dongeng dalam Isyarat</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('discussion');?>" class="nav-link">
                    <i class="nav-icon fas fa-comments text-lime"></i>
                    <p>Forum Diskusi</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('links');?>" class="nav-link">
                    <i class="nav-icon fas fa-link text-indigo"></i>
                    <p>Referensi</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('tentang');?>" class="nav-link">
                    <i class="nav-icon fas fa-question-circle text-orange"></i>
                    <p>Tentang</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= base_url('keluar');?>" class="nav-link">
                    <i class="nav-icon fas fa-power-off text-danger"></i>
                    <p class="text">Keluar</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>