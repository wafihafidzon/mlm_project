<!-- jQuery -->
<script src="<?= base_url() ?>assets/plugins/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
<!-- Popper 1.6 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
  integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
< /> <
!--Bootstrap 4-- >
<
script src = "https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
integrity = "sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"
crossorigin = "anonymous" >
</script>
<!-- Font Awesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"
  integrity="sha512-fzff82+8pzHnwA1mQ0dzz9/E0B+ZRizq08yZfya66INZBz86qKTCt9MLU0NCNIgaMJCgeyhujhasnFUsYMsi0Q=="
  crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Sweetalert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.2.2/dist/sweetalert2.all.min.js"
  integrity="sha256-OABKrwmx1gTjF5bLHbyKuTMHOd+fD76gQavBCJZLD3c=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url();?>assets/js/adminlte.js"></script>
<!-- Page specific script -->
<script type="text/javascript">
var Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  fixed: false,
  timer: 6000,
  showConfirmButton: false
});
<?php     
    $er = explode("." , $this->session->flashdata('message'));
    if ($er[0] == 'gagal'){ ?>
$(document).Toasts('create', {
  class: 'bg-danger',
  title: 'GMP - <?= $title;?>',
  body: '<?= $er[1];?>',
  icon: 'fas fa-exclamation-circle'
});
<?php }elseif($er[0] == 'berhasil'){ ?>
$(document).Toasts('create', {
  class: 'bg-success',
  title: 'GMP - <?= $title;?>',
  body: '<?= $er[1];?>',
  icon: 'fas fa-check-circle'
});
<?php }elseif($er[0] == 'peringatan'){ ?>
$(document).Toasts('create', {
  class: 'bg-warning',
  title: 'GMP - <?= $title;?>',
  body: '<?= $er[1];?>',
  icon: 'fas fa-exclamation-circle'
});
<?php }elseif($er[0] == 'info'){ ?>
$(document).Toasts('create', {
  class: 'bg-info',
  title: 'GMP - <?= $title;?>',
  body: '<?= $er[1];?>',
  icon: 'fas fa-info-circle'
});
<?php }     
		$this->session->set_flashdata('message', '');
    ?>
</script>