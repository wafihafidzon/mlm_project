 <!-- /.content-wrapper -->
 <footer class="main-footer " style="background-color:#1F6521;">
    <div class="float-right d-none d-sm-block" style="background-color:#1F6521;">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2023 <a href="<?= base_url();?>" style="color:white;"><?= SITE_NAME;?></a>.</strong> All rights reserved.
  </footer>