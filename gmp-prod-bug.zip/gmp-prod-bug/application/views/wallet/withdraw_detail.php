<!DOCTYPE html>
<html lang="id">

<head>
    <?php $this->load->view("_partials/head.php")?>
    <!-- Bootstrap CSS -->
    <style>
        .table td[rowspan] {
            vertical-align: middle;
            text-align: center;
        }

        .table {
            text-align: center;
        }
    </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-sm-inline-block">
                    <a href="#" class="nav-link">
                        <?=$title;?>
                    </a>
                </li>
            </ul>
        </nav>
        <?php $this->load->view("templates/sidebar.php")?>

        <div class="content-wrapper">
            <section class="content pt-3">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <h3>Withdraw</h3>
                            <form id="withdrawForm" action="<?=base_url('withdraw/withdraw_proses')?>" method="post">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" id="selectAll"></th>
                                            <th width="5%">No.</th>
                                            <th>Tanggal</th>
                                            <th>Total WD</th>
                                            <th>Member Id</th>
                                            <th>Nama Rekening</th>
                                            <th>Bank</th>
                                            <th>No. Rekening</th>
                                            <th>Potongan Admin</th>
                                            <th>Potongan Sedekah</th>
                                            <th>Potongan Transfer</th>
                                            <th>Transfer</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $no = 1;
                                        if(empty($withdraw)){ ?>
                                            <tr>
                                                <td colspan="13">Tidak ada data</td>
                                            </tr>
                                        <?php }
foreach ($withdraw as $withdraw): ?>
                                            <tr>
                                                <td><input type="checkbox" class="selectedCheckbox" name="selectedCheckbox[]" value="<?=$withdraw['id_withdraw_detail']?>"></td>
                                                <td><?=$no++?></td>
                                                <td><?=$withdraw['created_at']?></td>
                                                <td class="amount">Rp.<?=number_format($withdraw['amount'] ?? 0, 0, ',', '.')?></td>
                                                <td><?=$withdraw['member_id']?></td>
                                                <td><?=$withdraw['nama_rekening']?></td>
                                                <td><?=$withdraw['bank']?></td>
                                                <td><?=$withdraw['rekening']?></td>
                                                <td>Rp.<?=number_format($withdraw['potongan_admin'] ?? 0, 0, ',', '.')?></td>
                                                <td>Rp.<?=number_format($withdraw['potongan_sedekah'] ?? 0, 0, ',', '.')?></td>
                                                <td>Rp.<?=number_format($withdraw['biaya_transfer'] ?? 0, 0, ',', '.')?></td>
                                                <td>Rp.<?=number_format($withdraw['total_transfer'] ?? 0, 0, ',', '.')?></td>
                                                <td><span class="badge badge-<?php echo ($withdraw['status'] == "Transferred") ? "success" : "warning"; ?>"><?php echo $withdraw['status']; ?></span></td>
                                            </tr>
                                        <?php endforeach;?>
                                    </tbody>
                                </table>
                                <input type="hidden" name="id" value="<?= $withdraw_id ?>">
                                <button type="submit" class="btn btn-primary">Process</button>
                                <button type="button" class="btn btn-danger" name="rejectBtn" onclick="submitForm('reject', '<?= $withdraw_id ?>')">Reject</button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <?php $this->load->view("_partials/footer.php")?>
    <?php $this->load->view("_partials/js.php")?>
    <script>
       
    function submitForm(action, id) {
        // Menambahkan input tersembunyi ke dalam formulir sebelum mengirimkan
        var input1 = document.createElement("input");
        input1.type = "hidden";
        input1.name = "action";
        input1.value = action;
        document.getElementById("withdrawForm").appendChild(input1);
        
        var input2 = document.createElement("input");
        input2.type = "hidden";
        input2.name = "id";
        input2.value = id;
        document.getElementById("withdrawForm").appendChild(input2);

        // Mengirimkan formulir
        document.getElementById("withdrawForm").submit();
    }
$(document).ready(function() {
    $("#selectAll").change(function() {
        $(".selectedCheckbox").prop("checked", $(this).prop("checked"));
    });

    // $('#rejectBtn').click(function() {
    //     var selectedWithdraws = [];

    //     $('.selectedCheckbox:checked').each(function() {
    //         var idWithdrawDetail = $(this).val();
    //         selectedWithdraws.push({
    //             id_withdraw_detail: idWithdrawDetail,
    //             action: 'reject'
    //         });
    //     });

    //     $.ajax({
    //         type: 'POST',
    //         url: '<?=base_url('withdraw/withdraw_reject')?>',
    //         data: {
    //             selected_withdraws: selectedWithdraws
    //         },
    //         dataType: 'json',
    //         success: function(response) {
    //             console.log('Reject selected success:', response);
    //         },
    //         error: function(error) {
    //             console.error('Error processing reject:', error);
    //         }
    //     });
    // });

    // ...
});
</script>
</body>

</html>
