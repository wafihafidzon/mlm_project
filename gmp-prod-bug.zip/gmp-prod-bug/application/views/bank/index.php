<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php") ?>
  <!-- DataTables -->
  <style>
    .table td[rowspan] {
      vertical-align: middle;
      text-align: center;
    }

    .table {
      text-align: center;
    }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?= $title; ?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php") ?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h3>Laporan Bonus Sponsor</h3>
              <table class="table table-bordered" id="table-sponsor">
                <thead>
                  <tr>
                    <th>Nama Bank</th>
                    <th>Status</th>
                    <th>Tools</th>
                  </tr>
                </thead>

                <tbody>
                  <?php foreach ($bank as $bank) : ?>
                    <tr>
                      <td><?= $bank['nama'] ?></td>
                      <td><?php echo $bank['status'] == 1 ? "Aktif" : "Tidak Aktif"; ?></td>
                      <td><a href="<?= base_url('bank/edit/' . $bank['bank_id']) ?>" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $bank['bank_id'] ?>">Edit</a></td>
                    </tr>

                    <!-- Modal for Edit -->
                    <div class="modal fade" id="editModal<?= $bank['bank_id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $bank['bank_id'] ?>" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel<?= $bank['bank_id'] ?>">Edit Status</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <form action="<?= base_url('bank/update_status/' . $bank['bank_id']) ?>" method="post">
                              <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status">
                                  <option value="1" <?php echo $bank['status'] == 1 ? 'selected' : ''; ?>>Aktif</option>
                                  <option value="0" <?php echo $bank['status'] == 0 ? 'selected' : ''; ?>>Tidak Aktif</option>
                                </select>
                              </div>
                              <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
  <?php $this->load->view("_partials/footer.php") ?>
  <?php $this->load->view("_partials/js.php") ?>
  <!-- DataTables -->
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#table-sponsor').DataTable();
    });
  </script>
</body>

</html>
