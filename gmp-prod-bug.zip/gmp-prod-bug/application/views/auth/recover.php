<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title;?></title>
    <link rel="icon" type="image/png" href="<?= base_url();?>assets/img/favicon.png"/>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- Sweetalert -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url();?>assets/css/adminlte.css">   
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <img src="<?= base_url();?>assets/img/logo land.png" class="img-fluid" alt="GMP"> 
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Ganti Kata Sandi Anda</p>

      <form action="<?= base_url('ganti'); ?>" method="post">
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Kata Sandi">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <?= form_error('email', '<div class="input-group mb-3"><small class="text-danger">', '</small></div>'); ?>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Ulangi Kata Sandi">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <a href="<?= base_url('masuk');?>" class="btn btn-success btn-flat">Masuk</a>
            <button type="submit" class="btn btn-warning btn-flat float-right">Ubah Kata Sandi</button>
          </div>
          <!-- /.col -->
        </div>
      </form>
      <!-- /.card-body -->
    </div>
  <!-- /.card -->
  </div>
  <!-- /.login-box -->

  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <!-- Popper 1.6 -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <!-- Bootstrap 4 -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  <!-- Font Awesome -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js" integrity="sha512-fzff82+8pzHnwA1mQ0dzz9/E0B+ZRizq08yZfya66INZBz86qKTCt9MLU0NCNIgaMJCgeyhujhasnFUsYMsi0Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <!-- Sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.2.2/dist/sweetalert2.all.min.js" integrity="sha256-OABKrwmx1gTjF5bLHbyKuTMHOd+fD76gQavBCJZLD3c=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <!-- AdminLTE App -->
  <script src="<?= base_url();?>assets/js/adminlte.js"></script>
  <!-- Page specific script -->
  <script type="text/javascript">
    var Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      fixed: false,
      timer: 6000,
      showConfirmButton: false,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });  
    <?php     
    $er = explode(".",$this->session->flashdata('message'));
    if ($er[0] == 'gagal'){ ?>  
      $(document).Toasts('create', {
        class: 'bg-danger',
        title: 'GMP',
        body: '<?= $er[1];?>',
        icon: 'fas fa-exclamation-circle'
      });
    <?php }elseif($er[0] == 'berhasil'){ ?> 
      $(document).Toasts('create', {
        class: 'bg-success',
        title: 'GMP',
        body: '<?= $er[1];?>',
        icon: 'fas fa-check-circle'
      });
    <?php }elseif($er[0] == 'peringatan'){ ?> 
      $(document).Toasts('create', {
        class: 'bg-warning',
        title: 'GMP',
        body: '<?= $er[1];?>',
        icon: 'fas fa-exclamation-circle'
      });
    <?php }elseif($er[0] == 'info'){ ?> 
      $(document).Toasts('create', {
        class: 'bg-info',
        title: 'GMP',
        body: '<?= $er[1];?>',
        icon: 'fas fa-info-circle'
      });
    <?php }     
		$this->session->set_flashdata('message', '');
    ?>
  </script>
</body>
</html>
