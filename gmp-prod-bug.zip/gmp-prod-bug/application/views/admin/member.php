<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php") ?>
  <style>
  .table td[rowspan] {
    vertical-align: middle;
    text-align: center;
  }

  .table {
    text-align: center;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?= $title; ?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php") ?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h3>Data Member</h3>
              <table id="data-member" class="table table-bordered">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Member</th>
                    <th>Aktivasi</th>
                    <th>Join</th>
                    <th>Sponsor</th>
                    <th>Upline</th>
                    <th>Posisi</th>
                    <!-- <th>Edit</th> -->
                    <th>Login</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $no = 1;
                  foreach ($member as $member) : ?>
                  <tr>
                    <td rowspan="3"><?= $no++ ?></td>
                    <td><?= $member->member_id ?></td>
                    <td rowspan="3"><?= $member->paket_name ?></td>
                    <td rowspan="3"><?= $member->data_created ?></td>
                    <td><?= $member->sponsor_id ?></td>
                    <td><?= $member->upline_id ?></td>
                    <td rowspan="3"><?= $member->posisi ?></td>
                  </tr>
                  <tr>
                    <td><?= $member->member_name ?></td>
                    <td><?= $member->sponsor_username ?></td>
                    <td><?= $member->upline_username ?></td>
                  </tr>
                  <tr>
                    <td><?= $member->member_username ?></td>
                    <td><?= $member->sponsor_name ?></td>
                    <td><?= $member->upline_name ?></td>
                  </tr>
                  <?php endforeach; ?>
              </table>
            </div>
          </div>
      </section>
    </div>


  </div>
  <?php $this->load->view("_partials/footer.php") ?>
  <?php $this->load->view("_partials/js.php") ?>
  <script>
  $(document).ready(function() {
    $('#data-member').DataTable();
  });
  </script>
</body>

</html>