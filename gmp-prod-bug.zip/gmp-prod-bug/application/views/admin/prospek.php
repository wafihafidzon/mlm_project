<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php") ?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
  .table td[rowspan] {
    vertical-align: middle;
    text-align: center;
  }

  .table {
    text-align: center;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?= $title; ?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php") ?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h3>Data Prospek</h3>
              <table id="table-prospek" class="table table-bordered">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Sumber PV</th>
                    <th>Member Prospek</th>
                    <th>Hak Kloning</th>
                    <th>KTP</th>
                    <th>Tgl. Input</th>
                    <th>Tipe Pendaftaran</th>
                    <th>Status Pendaftaran</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                </ /?=var_dump($member) ?>
                <tbody>
                  <?php $no = 1;
                  foreach ($member as $member) : ?>
                  <tr>
                    <td><a href="<?= base_url('detail_member/' . $member->member_id) ?>"><?= $member->member_id ?></a>
                    </td>
                    <td><?= $member->paket_name ?></td>
                    <td><?= $member->member_name ?></td>
                    <td><?= $member->member_kloning ?></td>
                    <td><?= $member->no_identitas ?></td>
                    <td><?= $member->data_created ?></td>
                    <td><?php if ($member->kloning_id == '') {
                            echo 'New';
                          } else {
                            echo 'Kloning';
                          } ?></td>
                    <td style="vertical-align:middle; ">
                      <p style="margin-top: 8px" class="
                        <?php if ($member->member_is_active == 0) {
                          echo 'badge bg-warning';
                        } else {
                          echo 'badge bg-success';
                        } ?>">
                        <?php if ($member->member_is_active == 0) {
                          echo 'Waiting';
                        } else {
                          echo 'Approve';
                        } ?>
                      </p>
                    </td>
                    <td style="vertical-align: middle;">
                      <?php if ($member->member_is_active == 0) { ?>
                      <a style="padding-top: 0px;" href="<?= base_url('admin/approval_member/' . $member->member_id) ?>"
                        class="btn btn-info btn-sm">Approve</a>
                      <?php } ?>
                      <a style="padding-top: 0px;" href="<?= base_url('admin/login_member/' . $member->member_id) ?>"
                        class="btn btn-danger btn-sm">login</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
              </table>
            </div>
          </div>
      </section>
    </div>


  </div>
  <?php $this->load->view("_partials/footer.php") ?>
  <?php $this->load->view("_partials/js.php") ?>
  <script>
  $(document).ready(function() {
    $('#table-prospek').DataTable();
  });
  </script>
</body>

</html>