<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />

</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link"><?=$title;?></a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-5">
        <div class="container-fluid">
          <div class="row">

            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h4>Total Bonus</h4>
                  <table class="table table-bordered">
                    <tr>
                      <th>Bonus Sponsor</th>
                      <td style="text-align: right;">Rp <?php echo number_format($sum_bonus_sponsor['amount'] ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                      <th>Bonus Pasangan</th>
                      <td style="text-align: right;">Rp <?php echo number_format($sum_bonus_pasangan['amount'] ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                      <th>Bonus Titik</th>
                      <td style="text-align: right;">Rp <?php echo number_format($sum_bonus_titik['amount'] ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                      <th>Total</th>
                      <td style="text-align: right;">- Rp <?php echo number_format($sum_bonus ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h4>Pendaftaran Mitra</h4>
                  <table class="table table-bordered">
                    <tr>
                      <th>Silver</th>
                      <td style="text-align: right;">Rp <?php echo number_format($silver ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                      <th>Gold</th>
                      <td style="text-align: right;">Rp <?php echo number_format($gold ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                      <th>Platinum</th>
                      <td style="text-align: right;">Rp <?php echo number_format($platinum ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                      <th>Total</th>
                      <td style="text-align: right;">Rp <?php echo number_format($total ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h4>Bonus (Transfered)</h4>
                  <table class="table table-bordered">
                    <tr>
                      <th>Total</th>
                      <td style="text-align: right;">- Rp <?php echo number_format($transfered['total_transfer'] ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h4>Bonus (Pending)</h4>
                  <table class="table table-bordered">
                    <tr>
                      <th>Total</th>
                      <td style="text-align: right;">Rp <?php echo number_format($pending['total_transfer'] ?? 0, 0, ',', '.'); ?></td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h4>Upgrade Mitra</h4>
                  <table class="table table-bordered">
                    <tr>
                      <th>Gold</th>
                      <td style="text-align: right;">Rp </td>
                    </tr>
                    <tr>
                      <th>Platinum</th>
                      <td style="text-align: right;">Rp </td>
                    </tr>
                    <tr>
                      <th>Total</th>
                      <td style="text-align: right;">Rp </td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h4>E-Wallet</h4>
                  <table class="table table-bordered">
                    <tr>
                      <th>Member ID</th>
                      <th>Saldo</th>
                      <th>Bank</th>
                    </tr>
                    <tr>
                      <?php foreach ($wallet as $wallet) : ?>
                        <td><?= $wallet['member_id'] ?></td>
                        <td><?= $wallet['amount'] ?></td>
                        <td><?= $wallet['bank'] ?></td>
                      <?php endforeach; ?>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

    </div>
    </section>
    <!-- /.content -->
  </div>

  <?php $this->load->view("_partials/footer.php")?>

  </div>
  <?php $this->load->view("_partials/js.php")?>

  <!-- DataTables  & Plugins -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.colVis.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.print.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js">
  </script>
  <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap.js">
  </script>

  <!-- ChartJS -->
  <script src="<?=base_url();?>assets/plugins/chart.js/Chart.min.js"></script>
  <script>
  $(function() {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var areaChartCanvas = $('#areaChart').get(0).getContext('2d')

    var areaChartData = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [{
          label: 'Digital Goods',
          backgroundColor: 'rgba(60,141,188,0.9)',
          borderColor: 'rgba(60,141,188,0.8)',
          pointRadius: false,
          pointColor: '#3b8bba',
          pointStrokeColor: 'rgba(60,141,188,1)',
          pointHighlightFill: '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data: [28, 48, 40, 19, 86, 27, 90]
        },
        {
          label: 'Electronics',
          backgroundColor: 'rgba(210, 214, 222, 1)',
          borderColor: 'rgba(210, 214, 222, 1)',
          pointRadius: false,
          pointColor: 'rgba(210, 214, 222, 1)',
          pointStrokeColor: '#c1c7d1',
          pointHighlightFill: '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data: [65, 59, 80, 81, 56, 55, 40]
        },
      ]
    }

    var areaChartOptions = {
      maintainAspectRatio: false,
      responsive: true,
      legend: {
        display: false
      },
      scales: {
        xAxes: [{
          gridLines: {
            display: false,
          }
        }],
        yAxes: [{
          gridLines: {
            display: false,
          }
        }]
      }
    }

    // This will get the first returned node in the jQuery collection.
    new Chart(areaChartCanvas, {
      type: 'line',
      data: areaChartData,
      options: areaChartOptions
    })

    //-------------
    //- LINE CHART -
    //--------------
    var lineChartCanvas = $('#lineChart').get(0).getContext('2d')
    var lineChartOptions = $.extend(true, {}, areaChartOptions)
    var lineChartData = $.extend(true, {}, areaChartData)
    lineChartData.datasets[0].fill = false;
    lineChartData.datasets[1].fill = false;
    lineChartOptions.datasetFill = false

    var lineChart = new Chart(lineChartCanvas, {
      type: 'line',
      data: lineChartData,
      options: lineChartOptions
    })

    //-------------
    //- DONUT CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
    var donutData = {
      labels: [
        'Chrome',
        'IE',
        'FireFox',
        'Safari',
        'Opera',
        'Navigator',
      ],
      datasets: [{
        data: [700, 500, 400, 600, 300, 100],
        backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de'],
      }]
    }
    var donutOptions = {
      maintainAspectRatio: false,
      responsive: true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(donutChartCanvas, {
      type: 'doughnut',
      data: donutData,
      options: donutOptions
    })

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieData = donutData;
    var pieOptions = {
      maintainAspectRatio: false,
      responsive: true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })

    //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas = $('#barChart').get(0).getContext('2d')
    var barChartData = $.extend(true, {}, areaChartData)
    var temp0 = areaChartData.datasets[0]
    var temp1 = areaChartData.datasets[1]
    barChartData.datasets[0] = temp1
    barChartData.datasets[1] = temp0

    var barChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      datasetFill: false
    }

    new Chart(barChartCanvas, {
      type: 'bar',
      data: barChartData,
      options: barChartOptions
    })

    //---------------------
    //- STACKED BAR CHART -
    //---------------------
    var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d')
    var stackedBarChartData = $.extend(true, {}, barChartData)

    var stackedBarChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        xAxes: [{
          stacked: true,
        }],
        yAxes: [{
          stacked: true
        }]
      }
    }

    new Chart(stackedBarChartCanvas, {
      type: 'bar',
      data: stackedBarChartData,
      options: stackedBarChartOptions
    })
  })
  </script>
  <script>
  $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": true,
      "buttons": ["pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

    $("#example2").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": true,
      "buttons": ["pdf", "print"]
    }).buttons().container().appendTo('#example2_wrapper .col-md-6:eq(0)');

  });
  </script>

</body>

</html>