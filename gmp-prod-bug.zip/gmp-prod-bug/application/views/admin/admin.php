<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />

</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link"><?=$title;?></a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-5">
        <div class="container-fluid">
          <?php
if ($this->session->userdata('role_id') == '3') {
    ?>
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-12">
              <div class="card small-box">
                <div class="card-body">
                  <img class="img-fluid float-lg-right" src="<?=base_url();?>assets/img/dashboard-1.png" alt="Photo">
                  <div class="inner">
                    <h3 class="font-weight-light">Selamat Datang, <b><?=$profil['nama'];?></b></h3>
                    <p><?=longdate_indo(date("Y-m-d"));?></p>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    Rp. <?= number_format($sedekah_nasional['potongan_sedekah'] ?? 0, 0, ',', '.') ?>
                  </h3>

                  <p>Total Sedekah Nasional</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    Rp. <?= number_format($sedekah_nasional['potongan_sedekah'] ?? 0, 0, ',', '.') ?>
                  </h3>

                  <p>Total Jumlah Member</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    Rp. <?= number_format($total ?? 0, 0, ',', '.') ?>
                  </h3>

                  <p>Omset Belanja Produk / Paket</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>


            <?php
} elseif ($this->session->userdata('role_id') == '2') {
    ?>
            <div class="row">
            <?php if($profil['bank'] == "NO BANK") {?>
            <div class="alert alert-danger" role="alert">
              Data Bank Belum lengkap, segera lengkapi agar dapat melakukan pencairan
            </div>
            <?php } ?>
              <div class="col-12">
                <div class="card small-box">
                  <div class="card-body">
                    <img class="img-fluid float-lg-right" src="<?=base_url();?>assets/img/dashboard-1.png" alt="Photo">
                    <div class="inner">
                      <h3 class="font-weight-light">Selamat Datang, <b><?=$profil['nama'];?></b></h3>
                      <p><?=longdate_indo(date("Y-m-d"));?></p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-6">
                <div class="small-box bg-gradient-light">
                  <?php //var_dump($this->session->userdata('member_id')) ?>
                  <div class="inner">
                    <h3>
                      <?= $network['nama_paket'] ?>
                    </h3>

                    <p>Paket Anda</p>
                  </div>
                  <div class="icon">
                    <i class="fa-solid fa-list-check"></i>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="small-box bg-gradient-light">
                  <div class="inner">
                    <h3>
                      <?= $member['role']; ?>
                    </h3>

                    <p>Total Sedekah</p>
                  </div>
                  <div class="icon">
                    <i class="fa-solid fa-list-check"></i>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="small-box bg-gradient-light">
                  <div class="inner">
                    <h3>
                      <?= $member['pv']; ?>
                    </h3>

                    <p>Saldo PV Aktivasi</p>
                  </div>
                  <div class="icon">
                    <i class="fa-solid fa-list-check"></i>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="small-box bg-gradient-light">
                  <div class="inner">
                    <h3>
                      <?php if($bonus_prestasi['status_reward'] ?? '') { echo $bonus_prestasi['status_reward']; } else { echo '-'; } ?>
                    </h3>

                    <p>Status Prestasi</p>
                  </div>
                  <div class="icon">
                    <i class="fa-solid fa-list-check"></i>
                  </div>
                </div>
              </div>

              <div class="col-6"></div>
              <div class="col-6">
                <div class="inner">
                  <h3>
                    Statistik Bulan Ini
                  </h3>

                  <table class="table table-striped table-hover">
                    <tbody>
                      <tr>
                        <th scope="col">Bonus Sponsor</th>
                        <td style="text-align: right;">Rp.
                          <?= number_format($bonus_sponsor['amount'] ?? 0, 0, ',', '.') ?></td>
                      </tr>
                      <tr>
                        <th scope="col">Bonus Pasangan</th>
                        <td style="text-align: right;">Rp.
                          <?= number_format($bonus_pasangan['amount'] ?? 0, 0, ',', '.') ?></td>
                      </tr>
                      <tr>
                        <th scope="col">Bonus Titik</th>
                        <td style="text-align: right;">Rp.
                          <?= number_format($bonus_titik['amount'] ?? 0, 0, ',', '.') ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

          </div>
          <?php } elseif ($this->session->userdata('role_id') == '4' || $this->session->userdata('role_id') == '5') { ?>
          <div class="row">
            <?php if($profil['bank'] == "NO BANK") {?>
            <div class="alert alert-danger" role="alert">
              Data Bank Belum lengkap, segera lengkapi agar dapat melakukan pencairan
            </div>
            <?php } ?>
            <div class="col-12">
              <div class="card small-box">
                <div class="card-body">
                  <img class="img-fluid float-lg-right" src="<?=base_url();?>assets/img/dashboard-1.png" alt="Photo">
                  <div class="inner">
                    <h3 class="font-weight-light">Selamat Datang, <b><?=$profil['nama'];?></b></h3>
                    <p><?=longdate_indo(date("Y-m-d"));?></p>
                  </div>
                </div>
              </div>
            </div>


            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    Rp. <?= number_format($sedekah_nasional['potongan_sedekah'] ?? 0, 0, ',', '.') ?>
                  </h3>

                  <p>Total Sedekah Nasional</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    <?= $network['nama_paket'] ?>
                  </h3>

                  <p>Paket Anda</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    <?= $member['role']; ?>
                  </h3>

                  <p>Tipe Stokis</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    <?= $member['pv']; ?>
                  </h3>

                  <p>Saldo PV Aktivasi</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light"
                style="display: flex; justify-content: space-between; padding: 0px 35px 0px 35px;">
                <div class="inner">
                  <h3 style="text-align: center;">
                    <?=$jumlahMemberKaki['kiri'];?>
                  </h3>

                  <p style="text-align: center;">Downline Kiri</p>
                </div>
                <div class="inner">
                  <h3 style="text-align: center;">
                    <?=$jumlahMemberKaki['kanan'];?>
                  </h3>

                  <p style="text-align: center;">Downline Kanan</p></i>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="small-box bg-gradient-light">
                <div class="inner">
                  <h3>
                    <?= $bonus_prestasi['status_reward'] ? $bonus_prestasi['status_reward'] : '-' ?>
                  </h3>

                  <p>Status Prestasi</p>
                </div>
                <div class="icon">
                  <i class="fa-solid fa-list-check"></i>
                </div>
              </div>
            </div>

            <div class="col-6">
              <div class="inner">
                <h3>
                  Statistik Bulan Ini
                </h3>

                <table class="table table-striped table-hover">
                  <tbody>
                    <tr>
                      <th scope="col">Bonus Sponsor</th>
                      <td style="text-align: right;">Rp.
                        <?= number_format($bonus_sponsor['amount'] ?? 0, 0, ',', '.') ?></td>
                    </tr>
                    <tr>
                      <th scope="col">Bonus Pasangan</th>
                      <td style="text-align: right;">Rp.
                        <?= number_format($bonus_pasangan['amount'] ?? 0, 0, ',', '.') ?></td>
                    </tr>
                    <tr>
                      <th scope="col">Bonus Titik</th>
                      <td style="text-align: right;">Rp. <?= number_format($bonus_titik['amount'] ?? 0, 0, ',', '.') ?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <?php } ?>
    </div>
    </section>
    <!-- /.content -->
  </div>

  <?php $this->load->view("_partials/footer.php")?>

  </div>
  <?php $this->load->view("_partials/js.php")?>

  <!-- DataTables  & Plugins -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.colVis.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.print.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js">
  </script>
  <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap.js">
  </script>

  <!-- ChartJS -->
  <script src="<?=base_url();?>assets/plugins/chart.js/Chart.min.js"></script>
  <script>
  $(function() {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var areaChartCanvas = $('#areaChart').get(0).getContext('2d')

    var areaChartData = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [{
          label: 'Digital Goods',
          backgroundColor: 'rgba(60,141,188,0.9)',
          borderColor: 'rgba(60,141,188,0.8)',
          pointRadius: false,
          pointColor: '#3b8bba',
          pointStrokeColor: 'rgba(60,141,188,1)',
          pointHighlightFill: '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data: [28, 48, 40, 19, 86, 27, 90]
        },
        {
          label: 'Electronics',
          backgroundColor: 'rgba(210, 214, 222, 1)',
          borderColor: 'rgba(210, 214, 222, 1)',
          pointRadius: false,
          pointColor: 'rgba(210, 214, 222, 1)',
          pointStrokeColor: '#c1c7d1',
          pointHighlightFill: '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data: [65, 59, 80, 81, 56, 55, 40]
        },
      ]
    }

    var areaChartOptions = {
      maintainAspectRatio: false,
      responsive: true,
      legend: {
        display: false
      },
      scales: {
        xAxes: [{
          gridLines: {
            display: false,
          }
        }],
        yAxes: [{
          gridLines: {
            display: false,
          }
        }]
      }
    }

    // This will get the first returned node in the jQuery collection.
    new Chart(areaChartCanvas, {
      type: 'line',
      data: areaChartData,
      options: areaChartOptions
    })

    //-------------
    //- LINE CHART -
    //--------------
    var lineChartCanvas = $('#lineChart').get(0).getContext('2d')
    var lineChartOptions = $.extend(true, {}, areaChartOptions)
    var lineChartData = $.extend(true, {}, areaChartData)
    lineChartData.datasets[0].fill = false;
    lineChartData.datasets[1].fill = false;
    lineChartOptions.datasetFill = false

    var lineChart = new Chart(lineChartCanvas, {
      type: 'line',
      data: lineChartData,
      options: lineChartOptions
    })

    //-------------
    //- DONUT CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
    var donutData = {
      labels: [
        'Chrome',
        'IE',
        'FireFox',
        'Safari',
        'Opera',
        'Navigator',
      ],
      datasets: [{
        data: [700, 500, 400, 600, 300, 100],
        backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de'],
      }]
    }
    var donutOptions = {
      maintainAspectRatio: false,
      responsive: true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(donutChartCanvas, {
      type: 'doughnut',
      data: donutData,
      options: donutOptions
    })

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieData = donutData;
    var pieOptions = {
      maintainAspectRatio: false,
      responsive: true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })

    //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas = $('#barChart').get(0).getContext('2d')
    var barChartData = $.extend(true, {}, areaChartData)
    var temp0 = areaChartData.datasets[0]
    var temp1 = areaChartData.datasets[1]
    barChartData.datasets[0] = temp1
    barChartData.datasets[1] = temp0

    var barChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      datasetFill: false
    }

    new Chart(barChartCanvas, {
      type: 'bar',
      data: barChartData,
      options: barChartOptions
    })

    //---------------------
    //- STACKED BAR CHART -
    //---------------------
    var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d')
    var stackedBarChartData = $.extend(true, {}, barChartData)

    var stackedBarChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        xAxes: [{
          stacked: true,
        }],
        yAxes: [{
          stacked: true
        }]
      }
    }

    new Chart(stackedBarChartCanvas, {
      type: 'bar',
      data: stackedBarChartData,
      options: stackedBarChartOptions
    })
  })
  </script>
  <script>
  $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": true,
      "buttons": ["pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

    $("#example2").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": true,
      "buttons": ["pdf", "print"]
    }).buttons().container().appendTo('#example2_wrapper .col-md-6:eq(0)');

  });
  </script>

</body>

</html>