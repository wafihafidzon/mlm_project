<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
    .table td[rowspan] {
      vertical-align: middle;
      text-align: center;
    }

    .table {
      text-align: center;
    }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?=$title;?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h3>Log Transfer PV</h3>
              <button style="margin-bottom: 15px" class="btn btn-primary">Total Bonus Sponsor : <?="Rp " . number_format($sum_bonus['amount'] ?? 0, 0, ',', '.')?></button>
              <table id="table-log-pv" class="table table-bordered">
                <thead>
                  <tr>
                    <th>Pengirim</th>
                    <th>Penerima</th>
                    <th>Jumlah PV</th>
                    <th>Date</th>
                  </tr>
                </thead>

                <tbody>
                  <?php $no = 1;
// var_dump($sum_bonus);
foreach ($pv as $pv): ?>
                    <tr>
                      <td><?= $pv['pengirim_id'] ?></td>
                      <td><?= $pv['penerima'] ?></td>
                      <td><?= $pv['jumlah_pv'] ?></td>
                      <td><?= $pv['created_at'] ?></td>
                    </tr>
                  <?php endforeach;?>
              </table>
            </div>
          </div>
      </section>
    </div>


  </div>
  <?php $this->load->view("_partials/footer.php")?>
  <?php $this->load->view("_partials/js.php")?>
  <script>
  $(document).ready(function() {
    $('#table-log-pv').DataTable();
  });
  </script>
</body>

</html>