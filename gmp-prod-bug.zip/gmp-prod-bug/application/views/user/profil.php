<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php") ?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />

</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">Profil <?= $title; ?></a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php") ?>

    <div class="content-wrapper">
      <section class="content pt-5">
        <div class="container-fluid">
          <?php
          if ($this->session->userdata('role_id') == '1') {
              ?>
              <!-- Small boxes (Stat box) -->
              <div class="row">
                <div class="col-md-3">
                  <!-- Profile Image -->
                  <div class="card card-primary card-outline">
                    <div class="card-body box-profile">
                      <div class="text-center">
                        <img class="profile-user-img img-fluid img-circle"
                          src="<?= base_url(); ?>assets/img/profil/<?= $profil['foto_profil']; ?>"
                          alt="<?= $profil['nama']; ?>">
                      </div>
                      <h3 class="profile-username text-center"><?= $profil['nama']; ?></h3>
                      <p class="text-muted text-center"><?= $profil['instansi']; ?></p>
                      <ul class="list-group list-group-unbordered mb-3">
                        <li class="list-group-item">
                          <b>Proyek</b> <a class="float-right">5</a>
                        </li>
                        <li class="list-group-item">
                          <b>Proyek Selesai</b> <a class="float-right">3</a>
                        </li>
                        <li class="list-group-item">
                          <b>Proyek Berjalan</b> <a class="float-right">2</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <!-- About Me Box -->
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">About Me</h3>
                    </div>
                    <div class="card-body">
                      <strong><i class="far fa-id-card mr-1"></i> Pekerjaan</strong>
                      <p class="text-muted">
                        Jabatan: <?= $profil['pekerjaan'] . "</br>NPWP: " . $profil['npwp']; ?>
                      </p>
                      <hr>
                      <strong><i class="fas fa-tty mr-1"></i> Kontak</strong>
                      <p class="text-muted">
                        Telp: <?= $profil['telp'] . "</br>Wa: " . $profil['wa'] . "</br>email: " . $profil['email']; ?>
                      </p>
                      <hr>
                      <strong><i class="fas fa-map-marker-alt mr-1"></i> Alamat</strong>
                      <p class="text-muted">
                        <?= $profil['alamat'] . "</br>" . $profil['desa'] . ", " . $profil['kecamatan'] . "</br>" . $profil['kota'] . ", " . $profil['provinsi'] . "</br>" . $profil['kode_pos']; ?>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="card">
                    <div class="card-header p-2">
                      <ul class="nav nav-pills">
                        <li class="nav-item"><a class="nav-link " href="#activity" data-toggle="tab">Aktifitas</a></li>
                        <li class="nav-item"><a class="nav-link" href="#timeline" data-toggle="tab">Timeline</a></li>
                        <li class="nav-item"><a class="nav-link active" href="#settings" data-toggle="tab">Settings</a></li>
                      </ul>
                    </div>
                    <div class="card-body">
                      <div class="tab-content">
                        <div class=" tab-pane" id="activity">
                          <!-- Post -->
                          <div class="post">
                            <div class="user-block">
                              <img class="img-circle img-bordered-sm"
                                src="<?= base_url(); ?>assets/img/profil/<?= $profil['foto_profil']; ?>" alt="user image">
                              <span class="username">
                                <a href="#"><?= $profil['nama']; ?></a>
                                <a href="#" class="float-right btn-tool"><i class="fas fa-times"></i></a>
                              </span>
                              <span class="description"><?= $profil['email']; ?> - 7:30 PM</span>
                            </div>
                            <!-- /.user-block -->
                            <p>
                              Lorem ipsum represents a long-held tradition for designers,
                              typographers and the like. Some people hate it and argue for
                              its demise, but others ignore the hate as they create awesome
                              tools to help create filler text for everyone from bacon lovers
                              to Charlie Sheen fans.
                            </p>
                          </div>
                          <!-- /.post -->
                        </div>
                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="timeline">
                          <!-- The timeline -->
                          <div class="timeline timeline-inverse">
                            <!-- timeline time label -->
                            <div class="time-label">
                              <span class="bg-danger">
                                10 Feb. 2014
                              </span>
                            </div>
                            <!-- /.timeline-label -->
                            <!-- timeline item -->
                            <div>
                              <i class="fas fa-envelope bg-primary"></i>

                              <div class="timeline-item">
                                <span class="time"><i class="far fa-clock"></i> 12:05</span>

                                <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                                <div class="timeline-body">
                                  Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                                  weebly ning heekya handango imeem plugg dopplr jibjab, movity
                                  jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                                  quora plaxo ideeli hulu weebly balihoo...
                                </div>
                                <div class="timeline-footer">
                                  <a href="#" class="btn btn-primary btn-sm">Read more</a>
                                  <a href="#" class="btn btn-danger btn-sm">Delete</a>
                                </div>
                              </div>
                            </div>
                            <!-- END timeline item -->
                            <!-- timeline item -->
                            <div>
                              <i class="fas fa-user bg-info"></i>

                              <div class="timeline-item">
                                <span class="time"><i class="far fa-clock"></i> 5 mins ago</span>

                                <h3 class="timeline-header border-0"><a href="#">Sarah Young</a> accepted your friend
                                  request
                                </h3>
                              </div>
                            </div>
                            <!-- END timeline item -->
                            <!-- timeline item -->
                            <div>
                              <i class="fas fa-comments bg-warning"></i>

                              <div class="timeline-item">
                                <span class="time"><i class="far fa-clock"></i> 27 mins ago</span>

                                <h3 class="timeline-header"><a href="#">Jay White</a> commented on your post</h3>

                                <div class="timeline-body">
                                  Take me to your leader!
                                  Switzerland is small and neutral!
                                  We are more like Germany, ambitious and misunderstood!
                                </div>
                                <div class="timeline-footer">
                                  <a href="#" class="btn btn-warning btn-flat btn-sm">View comment</a>
                                </div>
                              </div>
                            </div>
                            <!-- END timeline item -->
                            <!-- timeline time label -->
                            <div class="time-label">
                              <span class="bg-success">
                                3 Jan. 2014
                              </span>
                            </div>
                            <!-- /.timeline-label -->
                            <!-- timeline item -->
                            <div>
                              <i class="fas fa-camera bg-purple"></i>

                              <div class="timeline-item">
                                <span class="time"><i class="far fa-clock"></i> 2 days ago</span>

                                <h3 class="timeline-header"><a href="#">Mina Lee</a> uploaded new photos</h3>
                              </div>
                            </div>
                            <!-- END timeline item -->
                            <div>
                              <i class="far fa-clock bg-gray"></i>
                            </div>
                          </div>
                        </div>
                        <!-- /.tab-pane -->

                        <div class="active tab-pane" id="settings">

                          <div class="timeline timeline-inverse">
                            <div>
                              <i class="fas fa-fingerprint bg-success"></i>

                              <div class="timeline-item">
                                <h3 class="timeline-header"><a href="#">Identitas</a> </h3>

                                <div class="timeline-body">
                                  <form class="form-horizontal" action="<?= base_url('profil/identitas'); ?>" method="post">
                                    <input type="hidden" class="form-control" id="token"
                                      value="<?= $this->session->userdata('member_id') ?>">
                                    <div class="form-group row">
                                      <label for="inputName" class="col-sm-2 col-form-label">Nama</label>
                                      <div class="col-sm-10">
                                        <input type="text" name="nama" class="form-control" id="inputName"
                                          placeholder="Nama Lengkap" value="<?= $profil['nama']; ?>">
                                      </div>
                                      <?= form_error('nama', '<div class="form-group"><small class="text-danger">', '</small></div>'); ?>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                                      <div class="col-sm-10">
                                        <input type="email" name="email" class="form-control" id="inputEmail"
                                          placeholder="Email" value="<?= $profil['email']; ?>" disabled>
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputName2" class="col-sm-2 col-form-label">Telp</label>
                                      <div class="col-sm-10">
                                        <input type="text" name="telp" class="form-control" id="inputName2"
                                          placeholder="Telp" value="<?= $profil['telp']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputExperience" class="col-sm-2 col-form-label">Whatsapp</label>
                                      <div class="col-sm-10">
                                        <input type="text" name="wa" class="form-control" id="inputExperience"
                                          placeholder="Whatsapp" value="<?= $profil['wa']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputSkills" class="col-sm-2 col-form-label">NPWP</label>
                                      <div class="col-sm-10">
                                        <input type="text" name="npwp" class="form-control" id="inputSkills"
                                          placeholder="NPWP" value="<?= $profil['npwp']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <div class="offset-sm-2 col-sm-10">
                                        <button type="submit" class="btn btn-success">Simpan</button>
                                      </div>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>

                            <div>
                              <i class="fas fa-id-card bg-primary"></i>

                              <div class="timeline-item">
                                <h3 class="timeline-header"><a href="#">Pekerjaan</a> </h3>

                                <div class="timeline-body">
                                  <form class="form-horizontal" action="<?= base_url('profil/pekerjaan'); ?>" method="post">
                                    <input type="hidden" class="form-control" id="token"
                                      value="<?= $this->session->userdata('member_id') ?>">
                                    <div class="form-group row">
                                      <label for="inputName" class="col-sm-2 col-form-label">Instansi</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName" placeholder="Nama Instansi"
                                          value="<?= $profil['instansi']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputEmail" class="col-sm-2 col-form-label">Logo Instansi</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputEmail" placeholder="Logo Instansi"
                                          value="<?= $profil['logo_instansi']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputName2" class="col-sm-2 col-form-label">Jabatan</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName2" placeholder="Jabatan"
                                          value="<?= $profil['pekerjaan']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <div class="offset-sm-2 col-sm-10">
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                      </div>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>

                            <div>
                              <i class="fas fa-map-marker-alt bg-info"></i>

                              <div class="timeline-item">
                                <h3 class="timeline-header"><a href="#">Alamat</a> </h3>

                                <div class="timeline-body">
                                  <form class="form-horizontal" action="<?= base_url('profil/alamat'); ?>" method="post">
                                    <input type="hidden" class="form-control" id="token"
                                      value="<?= $this->session->userdata('member_id') ?>">
                                    <div class="form-group row">
                                      <label for="inputName" class="col-sm-2 col-form-label">Alamat</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName" placeholder="Alamat"
                                          value="<?= $profil['alamat']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputEmail" class="col-sm-2 col-form-label">Desa</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputEmail" placeholder="Desa"
                                          value="<?= $profil['desa']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputName2" class="col-sm-2 col-form-label">Kecamatan</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName2" placeholder="Kecamatan"
                                          value="<?= $profil['kecamatan']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputName2" class="col-sm-2 col-form-label">Kota</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName2" placeholder="Kota"
                                          value="<?= $profil['kota']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputName2" class="col-sm-2 col-form-label">Provinsi</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName2" placeholder="Provinsi"
                                          value="<?= $profil['provinsi']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputName2" class="col-sm-2 col-form-label">Kode Pos</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputName2" placeholder="Kode Pos"
                                          value="<?= $profil['kode_pos']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <div class="offset-sm-2 col-sm-10">
                                        <button type="submit" class="btn btn-info">Simpan</button>
                                      </div>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>

                            <div>
                              <i class="fas fa-lock bg-warning"></i>

                              <div class="timeline-item">
                                <h3 class="timeline-header"><a href="#">Password</a> </h3>

                                <div class="timeline-body">
                                  <form class="form-horizontal" action="<?= base_url('profil/password'); ?>" method="post">
                                    <input type="hidden" class="form-control" id="token"
                                      value="<?= $this->session->userdata('member_id') ?>">
                                    <div class="form-group row">
                                      <label for="inputName" class="col-sm-2 col-form-label">Password</label>
                                      <div class="col-sm-10">
                                        <input type="password" class="form-control" id="inputName" placeholder="Password">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <label for="inputEmail" class="col-sm-2 col-form-label">Repassword</label>
                                      <div class="col-sm-10">
                                        <input type="password" class="form-control" id="inputEmail"
                                          placeholder="Ulangi Password">
                                      </div>
                                    </div>
                                    <div class="form-group row">
                                      <div class="offset-sm-2 col-sm-10">
                                        <button type="submit" class="btn btn-warning">Simpan</button>
                                      </div>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>

                            <div>
                              <i class="far fa-user bg-gray"></i>
                            </div>
                          </div>
                        </div>
                        <!-- /.tab-pane -->
                      </div>
                      <!-- /.tab-content -->
                    </div>
                  </div>
                </div>
              </div>

          <?php
          } elseif ($this->session->userdata('role_id') == '2') {
              ?>
              <div class="row">
                <div class="col-lg-2 col-6">
                  <!-- small box -->
                  <div class="small-box bg-gradient-cyan">
                    <div class="inner">
                      <h3><?= $material['material']; ?></h3>

                      <p>Materi</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-folder-open"></i>
                    </div>
                    <a href="<?= base_url('material'); ?>" class="small-box-footer">Selanjutnya <i
                        class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-2 col-6">
                  <!-- small box -->
                  <div class="small-box bg-gradient-yellow">
                    <div class="inner">
                      <h3><?= $dongeng['dongeng']; ?></h3>

                      <p>Dongeng</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-video"></i>
                    </div>
                    <a href="<?= base_url('dongeng'); ?>" class="small-box-footer">Selanjutnya <i
                        class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-2 col-6">
                  <!-- small box -->
                  <div class="small-box bg-gradient-maroon">
                    <div class="inner">
                      <h3><?= $practice['practice']; ?></h3>

                      <p>Latihan</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-gamepad"></i>
                    </div>
                    <a href="<?= base_url('practice'); ?>" class="small-box-footer">Selanjutnya <i
                        class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <!-- ./col -->
                <div class="col-lg-2 col-6">
                  <!-- small box -->
                  <div class="small-box bg-gradient-green">
                    <div class="inner">
                      <h3>.</h3>

                      <p>Forum</p>
                    </div>
                    <div class="icon">
                      <i class="far fa-comments"></i>
                    </div>
                    <a href="<?= base_url('discussion'); ?>" class="small-box-footer">Selanjutnya <i
                        class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <!-- ./col -->
                <div class="col-lg-2 col-6">
                  <!-- small box -->
                  <div class="small-box bg-gradient-indigo">
                    <div class="inner">
                      <h3>.</h3>

                      <p>Referensi</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-link"></i>
                    </div>
                    <a href="<?= base_url('links'); ?>" class="small-box-footer">Selanjutnya <i
                        class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <!-- ./col -->
                <div class="col-lg-2 col-6">
                  <!-- small box -->
                  <div class="small-box bg-gradient-orange">
                    <div class="inner">
                      <h3>.</h3>

                      <p>Tentang</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-question-circle"></i>
                    </div>
                    <a href="<?= base_url('tentang'); ?>" class="small-box-footer">Selanjutnya <i
                        class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
        <?php } ?>
    </div>
    </section>
    <!-- /.content -->
  </div>

  <?php $this->load->view("_partials/footer.php") ?>

  </div>
  <?php $this->load->view("_partials/js.php") ?>

  <!-- DataTables  & Plugins -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.colVis.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.print.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js">
  </script>
  <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap.js"></script>
  <script>
  $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": true,
      "buttons": ["pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

    $("#example2").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": true,
      "buttons": ["pdf", "print"]
    }).buttons().container().appendTo('#example2_wrapper .col-md-6:eq(0)');

  });
  </script>

</body>

</html>