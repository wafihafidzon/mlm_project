<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
  .table td[rowspan] {
    vertical-align: middle;
    text-align: center;
  }

  .table {
    text-align: center;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?=$title;?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="card col-md-12">
            <div class="card card-header">
              <h3>Transfer PV</h3>
            </div>
            <div class="row">
              <div class="col-md-12">
                <?php
if ($this->session->flashdata('error')) {
    var_dump($this->session->flashdata('error'));
}
?>
                <form method="post" action="<?=base_url('member/transfer_pv')?>">
                  <div class="card-body">
                    <label for="" class="btn btn-primary">Saldo PV : <?=$pv['pv']?></label>
                    <div style="display: flex; flex-direction: row; align-items: center">
                      <label style="width:fit-content;">Username</label>
                      <input type="text" class="form-control" name="member_id" placeholder="GMPS-XXXXXX"
                        style="margin-left: 30px;">
                    </div>
                  </div>
                  <div class="card-body">
                    <div style="display: flex; flex-direction: row; align-items: center">
                      <label style="width:fit-content;">Jumlah PV</label>
                      <ul class="pagination pagination-md" style="margin-left: 30px;">
                        <input type="number" class="form-control" id="inputNilai" name="jumlah_pv" value="0"
                          style="text-align: center;">
                      </ul>
                    </div>
                  </div>
                  <div class="card-body">
                    <div style="display: flex; flex-direction: row; align-items: center">
                      <label style="width:fit-content;">Password</label>
                      <input type="password" class="form-control" name="password" placeholder="********"
                        style="margin-left: 30px;">
                    </div>
                  </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-info">Submit</button>
          </div>
          </form>
        </div>
      </section>
    </div>

    <script>
    const batasAtas = <?= $pv['pv'] ?>;
    let nilaiInput = document.getElementById("inputNilai");

    // Fungsi untuk membatasi nilai input
    function batasiNilai() {
      let nilai = parseInt(nilaiInput.value);
      if (isNaN(nilai) || nilai < 0) {
        nilai = 0;
      } else if (nilai > batasAtas) {
        nilai = batasAtas;
      }
      nilaiInput.value = nilai;
    }

    // Tambahkan event listener pada input untuk memanggil fungsi ketika nilainya berubah
    nilaiInput.addEventListener("input", batasiNilai);
    </script>
    </script>

    <?php $this->load->view("_partials/footer.php")?>
    <?php $this->load->view("_partials/js.php")?>
</body>

</html>