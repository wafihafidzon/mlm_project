<!DOCTYPE html>
<html lang="id">

<head>
	<?php $this->load->view("_partials/head.php")?>
	<!-- DataTables -->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
	<link rel="stylesheet" type="text/css"
		href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
	<link rel="stylesheet" type="text/css"
		href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />

</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<div class="wrapper">
		<nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
				</li>
				<li class="nav-item d-sm-inline-block">
					<a href="#" class="nav-link"><?=$title;?></a>
				</li>
			</ul>
		</nav>
		<?php $this->load->view("templates/sidebar_member.php")?>

		<div class="content-wrapper">
			<section class="content pt-5">
				<div class="container-fluid">
						<!-- Small boxes (Stat box) -->
						<div class="row">
							<div class="col-12">
								<div class="card small-box">
									<div class="card-body">
										<img class="img-fluid float-lg-right"
											src="<?=base_url();?>assets/img/dashboard-1.png" alt="Photo">
										<div class="inner">
											<h3 class="font-weight-light">Selamat Datang, <b><?=$profil['nama'];?></b></h3>
											<p><?=longdate_indo(date("Y-m-d"));?></p>
										</div>
									</div>
								</div>
							</div>
							<div class="col-6">
								<div class="small-box bg-gradient-light">
									<div class="inner">
										<h3>
											<?=$paket['nama'];?>
										</h3>

										<p>Paket Anda</p>
									</div>
									<div class="icon">
										<i class="fa-solid fa-list-check"></i>
									</div>
								</div>
							</div>
							<div class="col-6">
								<div class="small-box bg-gradient-light" style="display: flex; justify-content: space-between; padding: 0px 35px 0px 35px;">
									<div class="inner">
										<h3 style="text-align: center;">
											<?=$jumlahMemberKaki['kiri'];?>
										</h3>

										<p style="text-align: center;">Downline Kiri</p>
									</div>
									<div class="inner">
										<h3 style="text-align: center;">
											<?=$jumlahMemberKaki['kanan'];?>
										</h3>

										<p style="text-align: center;">Downline Kanan</p></i>
									</div>
								</div>
							</div>
							<div class="col-6">
								<div class="small-box bg-gradient-light">
									<div class="inner">
										<h3>
											<?=$saldo_pv['pv'];?>
										</h3>

										<p>Saldo PV</p>
									</div>
									<div class="icon">
										<i class="fa-solid fa-list-check"></i>
									</div>
								</div>
							</div>
							<div class="col-6">
							</div>
						</div>

		</div>
		</section>
		<!-- /.content -->
	</div>

	<?php $this->load->view("_partials/footer.php")?>

	</div>
	<?php $this->load->view("_partials/js.php")?>

	<!-- DataTables  & Plugins -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.colVis.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.html5.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.print.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js">
	</script>
	<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap.js">
	</script>

	<!-- ChartJS -->

</body>

</html>