<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js@9.0.1/public/assets/styles/choices.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
  .table td[rowspan] {
    vertical-align: middle;
    text-align: center;
  }

  .table {
    text-align: center;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?=$title;?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="card col-md-12">
            <div class="card card-header">
              <h3>Prospek Member</h3>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="card card-primary m-3">
                  <div class="card-body">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="flexRadioDefault" id="kloning">
                      <label class="form-check-label" for="flexRadioDefault1">
                        Kloning
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="flexRadioDefault" id="new" checked>
                      <label class="form-check-label" for="flexRadioDefault2">
                        New
                      </label>
                      <input type="hidden" name="kloning" id="kloning">
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <?php
                  if ($this->session->flashdata('error')) {
                    echo '<div class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                  }
                  ?>
                  <div class="card-header">
                    <h3 class="card-title">Data Prospek Member</h3>
                  </div>
                  <form method="post" action="<?=base_url('member/insert_member')?>">
                    <div class="card-body">
                      <div class="form-group">
                        <label>Nomer HP</label>
                        <input type="number" class="form-control" id="no_hp" name="no_hp">
                      </div>
                      <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" id="username" name="username">
                      </div>
                      <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap">
                      </div>
                      <div class="form-group">
                        <label>No. KTP</label>
                        <input type="number" class="form-control" id="ktp" name="ktp">
                      </div>
                    </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Data Bank</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Bank</label>
                      <select class="form-control" name="bank" id="bank">
                        <option value="" selected>NO BANK</option>a
                        <?php foreach ($bank as $bank): ?>
                        <option value="<?=$bank['bank_id']?>" <?php if($profil['bank'] == $bank['bank_id']) {echo "selected";} ?>>
                          <?=$bank['nama']?>
                        </option>
                        <?php endforeach;?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Nama Pemilik Rekening</label>
                      <input type="text" class="form-control" name="no_rekening" id="nama_rekening" readonly>
                    </div>
                    <div class="form-group">
                      <label>Nomer Rekening</label>
                      <input type="text" class="form-control" id="no_rekening" name="no_rekening">
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Data Jaringan</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group username_upline">
                      <div style="display: flex; justify-content: space-between">
                        <label>Upline</label>
                        <div>
                          <input type="checkbox" class="form-check-input" id="isUpline">
                          <label for="">Saya adalah upline</label>
                        </div>
                      </div>
                      <input type="text" class="form-control" id="username_upline" name="username_upline">
                    </div>
                    <div class="mitra-sponsor">
                      <label>Posisi</label>
                      <div class="form-check">
                        <input type="radio" class="form-check-input" checked value="Kiri" name="posisi" id="radio-kiri">
                        <label>Kiri</label>
                      </div>
                      <div class="form-check">
                        <input type="radio" class="form-check-input" value="Kanan" name="posisi" id="radio-kanan">
                        <label>Kanan</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Paket Pendaftaran</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Paket Pendaftaran</label> <br>
                      <label>Total PV : Unlimited</label>
                      <select class="form-control" id="paket_id" name="paket_id">
                        <option value="" selected hidden>Select Menu</option>
                        <?php foreach ($paket as $p): ?>
                        <option id="<?=$p['paket_id']?>" value="<?=$p['paket_id']?>">
                          <?=$p['nama']?>
                        </option>
                        <?php endforeach;?>
                      </select>
                      <input type="text" hidden class="pv" name="pv">
                      <div class="form-group" style="margin-top: 5px;" id="jumlahKloningContainer">
                        <label>Kloning</label>
                        <input type="number" class="form-control" id="jmlKloning" name="jmlKloning">
                      </div>
                        <label>Pin Kosong</label>
                      <select class="form-select" name="pin_kosong" aria-label="Default select example">
                        <option selected hidden>Pin Kosong ?</option>
                        <option value="1">Ya</option>
                        <option value="0">Tidak</option>
                        </select>
                    </div>
                  </div>
                </div>
                <div class="card card-primary m-3">
                  <div class="card-header">
                    <h3 class="card-title">Akun</h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Email</label>
                      <input type="text" class="form-control" name="email">
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input type="text" class="form-control" name="password">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <button type="submit" id="submit" class="btn btn-info">Submit</button>
          </div>
          </form>
        </div>
      </section>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script>
    const pv = "<?=$pv['pv'] ?>";
    const gold = document.getElementById('AUmpTd0eiDiySMkyiR');
    const silver = document.getElementById('n2NEePzD6cjti86Aki');
    const platinum = document.getElementById('ghuSXbKMduS3LMz2Ve');
    const submit = document.getElementById('submit');
    const isUpline = document.getElementById('isUpline');
    const upline = document.getElementById('username_upline');

    const noHp = document.getElementById('no_hp');
    const username = document.getElementById('username');
    const namaLengkap = document.getElementById('nama_lengkap');
    const ktp = document.getElementById('ktp');
    const jenisKelamin = document.getElementById('jenis_kelamin');
    const bank = document.getElementById('bank');
    const noRekening = document.getElementById('no_rekening');
    const namaRekening = document.getElementById('nama_rekening');

    const radioKanan = document.getElementById('radio-kanan');
    const radioKiri = document.getElementById('radio-kiri');

    const paket = document.getElementById('paket_id');

    const jmlKloning = document.getElementById('jmlKloning');

    jmlKloning.addEventListener('keyup', function() {
      if (parseInt(jmlKloning.value) > maxKloning) {
        jmlKloning.value = maxKloning
      }
    })


    const calonDownline = "<?= $calon_downline ?>"
    const posisiCalon = "<?= $posisi_calon ?>"

    const kloningForm = document.getElementById('kloning');
    const jumlahKloningContainer = document.getElementById('jumlahKloningContainer');

    jumlahKloningContainer.style.display = 'none';

    if (calonDownline != 'kosong') {
      isUpline.checked = true
      upline.value = calonDownline
      upline.readOnly = true

      if (posisiCalon == 'kiri') {
        radioKiri.checked = true
      } else {
        radioKanan.checked = true
      }
    }

    console.log(radioKanan)
    namaLengkap.addEventListener('keyup', function(event) {
      let inputData = event.target.value;
      namaRekening.value = inputData;
    })


    const kloning = document.getElementById('kloning');
    const newMember = document.getElementById('new');

    isUpline.addEventListener('change', function() {
      if (this.checked) {
        upline.value = "<?= $this->session->userdata('member_id') ?>";
        upline.readOnly = true
      } else {
        upline.value = "";
        upline.readOnly = false
      }
    })

    kloning.addEventListener('change', function() {
      username.value = "<?= $member['username'] ?>";
      namaLengkap.value = "<?= $profil['nama'] ?>";
      ktp.value = "<?= $profil['no_identitas'] ?>";
      namaRekening.value = "<?= $profil['nama'] ?>";
      noRekening.value = "<?= $profil['rekening'] ?>";

      if (bank.value == "<?= $profil['bank'] ?>") {
        bank.selected == true
      }

      jumlahKloningContainer.style.display = 'block';
    });

    newMember.addEventListener('change', function() {
      username.value = "";
      namaLengkap.value = "";
      ktp.value = "";

      noHp.readOnly = false
      username.readOnly = false
      namaLengkap.readOnly = false
      ktp.readOnly = false
      kloningForm.value = ''
      jumlahKloningContainer.style.display = 'none';
    });
    </script>
    <?php $this->load->view("_partials/footer.php")?>
    <?php $this->load->view("_partials/js.php")?>
</body>

</html>