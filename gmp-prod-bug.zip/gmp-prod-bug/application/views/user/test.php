<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php")?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
  table {
    border-collapse: collapse;
    width: 100%;
  }

  td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: center;
    width: 25%;
  }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?=$title;?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php")?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h3>Upline TREE</h3>
              <table class="table table-bordered">
                <tr>
                  <td colspan="4">
                    <br>
                    <img src="<?=base_url();?>assets/img/profil/<?=$profil['foto_profil'];?>"
                      class="img-circle elevation-2" width="70px" style="margin-bottom: 10px;"
                      alt="<?=$profil['nama'];?>">
                    <br>
                    <?=$kolom1['member_id'] ?? '-'?>
                    <br>
                    <?=$kolom1['nama_paket'] ?? '-'?>
                    <br>
                    <?=$kolom1['nama_member'] ?? '-'?>
                    <br>
                    <div style="display: flex; justify-content: space-around;">
                      <span class="text-danger"><?php if(isset($kolom1)) echo $kolom1['total_kiri'] . "[kiri] " . $kolom1['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom1)) echo $kolom1['total_kanan'] . "[kanan] " . $kolom1['point_pasangan'] ?></span>
                    </div>
                  </td>
                </tr>

                <tr>
                  <td colspan="2">
                    <br>
                    <a href="<?= base_url('network/index/' . @$kolom2kiri['member_id']) ?>">
                      <img
                        src="<?php if (@$kolom2kiri['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=$kolom2kiri['member_id'] ?? '-'?>
                      <br>
                      <?=$kolom2kiri['nama_paket'] ?? '-'?>
                      <br>
                      <?=$kolom2kiri['nama_member'] ?? '-'?>
                    </a>
                    <?php if (@$kolom2kiri['member_id'] == null) { ?>
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom1['member_id'] ."&posisi=kiri") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php }; ?>
                    <br>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom2kiri)) echo $kolom2kiri['total_kiri'] . "[kiri] " . $kolom2kiri['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom2kiri)) echo $kolom2kiri['total_kanan'] . "[kanan] " . $kolom2kiri['point_pasangan'] ?></span>
                    </div>
                  </td>
                  <td colspan="2">
                    <br>
                    <a href="<?= base_url('network/index/' . @$kolom2kanan['member_id']) ?>">
                      <img
                        src="<?php if (@$kolom2kanan['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=$kolom2kanan['member_id'] ?? '-'?>
                      <br>
                      <?=$kolom2kanan['nama_paket'] ?? '-'?>
                      <br>
                      <?=$kolom2kanan['nama_member'] ?? '-'?>
                    </a>
                    <?php if (@$kolom2kanan['member_id'] == null) { ?>
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom1['member_id'] ."&posisi=kanan") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php }; ?>
                    <br>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom2kanan)) echo $kolom2kanan['total_kiri'] . "[kiri] " . $kolom2kanan['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom2kanan)) echo $kolom2kanan['total_kanan'] . "[kanan] " . $kolom2kanan['point_pasangan'] ?></span>
                    </div>
                  </td>
                </tr>

                <tr>
                  <td>
                    <br><?php if(isset($kolom3KiriBag1)){?>
                    <a href="<?= base_url('network/index/' . @$kolom3KiriBag1['member_id']) ?>">
                      <?php } ?>
                      <img
                        src="<?php if (@$kolom3KiriBag1['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=$kolom3KiriBag1['member_id'] ?? '-'?>
                      <br>
                      <?=$kolom3KiriBag1['nama_paket'] ?? '-'?>
                      <br>
                      <?=$kolom3KiriBag1['nama_member'] ?? '-'?>
                    </a>
                    <?php if (@$kolom3KiriBag1['member_id'] == null && @$kolom2kiri['member_id'] != null) { ?>
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom2kiri['member_id'] ."&posisi=kiri") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php }; ?>
                    <br>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom3KiriBag1)) echo $kolom3KiriBag1['total_kiri'] . "[kiri] " . $kolom3KiriBag1['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom3KiriBag1)) echo $kolom3KiriBag1['total_kanan'] . "[kanan] " . $kolom3KiriBag1['point_pasangan'] ?></span>
                    </div>
                  </td>
                  <td>
                    <br>
                    <?php if(isset($kolom3KiriBag2)){?>
                    <a href="<?= base_url('network/index/' . @$kolom3KiriBag2['member_id']) ?>">
                      <?php } ?>
                      <img
                        src="<?php if (@$kolom3KiriBag2['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=$kolom3KiriBag2['member_id'] ?? '-'?>
                      <br>
                      <?=$kolom3KiriBag2['nama_paket'] ?? '-'?>
                      <br>
                      <?=$kolom3KiriBag2['nama_member'] ?? '-'?>
                    </a>
                    <?php if (@$kolom3KiriBag2['member_id'] == null && @$kolom2kiri['member_id'] != null) { ?>
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom2kiri['member_id'] ."&posisi=kanan") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php }; ?>
                    <br>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom3KiriBag2)) echo $kolom3KiriBag2['total_kiri'] . "[kiri] " . $kolom3KiriBag2['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom3KiriBag2)) echo $kolom3KiriBag2['total_kanan'] . "[kanan] " . $kolom3KiriBag2['point_pasangan'] ?></span>
                    </div>
                  </td>
                  <td>
                    <br>
                    <?php 
                    if(isset($kolom3kanan) && isset($kolom2kanan)){
                      if(@$kolom3kanan[0]['posisi']=='Kiri'){ ?>

                    <a href="<?= base_url('network/index/' . @$kolom3kanan[0]['member_id']) ?>">
                      <img
                        src="<?php if (@$kolom3kanan[0]['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=@$kolom3kanan[0]['member_id'] ?? '-'?>
                      <br>
                      <?=@$kolom3kanan[0]['nama_paket'] ?? '-'?>
                      <br>
                      <?=@$kolom3kanan[0]['nama_member'] ?? '-'?>
                    </a>
                    <?php if (@$kolom3kanan[0]['member_id'] == null && @$kolom2kanan['member_id'] != null) { ?>
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom2kanan['member_id'] ."&posisi=kiri") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php } ?>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom3kanan[0])) echo $kolom3kanan[0]['total_kiri'] . "[kiri] " . $kolom3kanan[0]['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom3kanan[0])) echo $kolom3kanan[0]['total_kanan'] . "[kanan] " . $kolom3kanan[0]['point_pasangan'] ?></span>
                    </div>
                    <?php }else{?>

                    <img src="<?php echo base_url('assets/img/download.jpeg');?>" class="img-circle elevation-2"
                      width="70px" height="70px" alt="<?=$profil['nama'];?>" style="margin-bottom: 10px;">
                    <br>
                    -
                    <br>
                    -
                    <br>
                    -
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom2kanan['member_id'] ."&posisi=kiri") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php }}else{ ?>
                    <img src="<?php echo base_url('assets/img/download.jpeg');?>" class="img-circle elevation-2"
                      width="70px" height="70px" alt="<?=$profil['nama'];?>" style="margin-bottom: 10px;">
                    <br>
                    -
                    <br>
                    -
                    <br>
                    -
                    <br>
                    <?php } ?>
                  </td>
                  <td>
                    <br>
                    <?php if(isset($kolom3kanan) && @$kolom3kanan[0]['posisi']=='Kanan'){ ?>
                    <a href="<?= base_url('network/index/' . @$kolom3kanan[0]['member_id']) ?>">
                      <img
                        src="<?php if (@$kolom3kanan[0]['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=@$kolom3kanan[0]['member_id'] ?? '-'?>
                      <br>
                      <?=@$kolom3kanan[0]['nama_paket'] ?? '-'?>
                      <br>
                      <?=@$kolom3kanan[0]['nama_member'] ?? '-'?>
                    </a>
                    <?php if (@$kolom3kanan[0]['member_id'] == null && @$kolom2kanan['member_id'] != null) { ?>
                    <div style="height: 40px; margin-top: 10px">
                      <a href="<?= base_url("memberview/add_member?id=" . $kolom2kanan['member_id'] ."&posisi=kanan") ?>"
                        class="btn btn-primary">Daftar</a>
                    </div>
                    <?php }; ?>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom3kanan[0])) echo $kolom3kanan[0]['total_kiri'] . "[kiri] " . $kolom3kanan[0]['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom3kanan[0])) echo $kolom3kanan[0]['total_kanan'] . "[kanan] " . $kolom3kanan[0]['point_pasangan'] ?></span>
                    </div>
                    <?php }else{?>
                    <?php if(isset($kolom3kanan)){?>
                    <a href="<?= base_url('network/index/' . @$kolom3kanan[1]['member_id']) ?>">
                      <?php }?>
                      <img
                        src="<?php if (@$kolom3kanan[1]['member_id'] == null) {echo base_url('assets/img/download.jpeg');}else{echo base_url('assets/img/profil/'. $profil['foto_profil']);}?>"
                        class="img-circle elevation-2" width="70px" height="70px" alt="<?=$profil['nama'];?>"
                        style="margin-bottom: 10px;">
                      <br>
                      <?=@$kolom3kanan[1]['member_id'] ?? '-'?>
                      <br>
                      <?=@$kolom3kanan[1]['nama_paket'] ?? '-'?>
                      <br>
                      <?=@$kolom3kanan[1]['nama_member'] ?? '-'?>
                      <?php if (@$kolom3kanan[1]['member_id'] == null && @$kolom2kanan['member_id'] != null) { ?>
                      <div style="height: 40px; margin-top: 10px">
                        <a href="<?= base_url("memberview/add_member?id=" . $kolom2kanan['member_id'] ."&posisi=kanan") ?>"
                          class="btn btn-primary">Daftar</a>
                      </div>
                      <?php }; ?>
                    </a>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px">
                      <span
                        class="text-danger"><?php if(isset($kolom3kanan[1])) echo $kolom3kanan[1]['total_kiri'] . "[kiri] " . $kolom3kanan[1]['point_pasangan'] ?></span>
                      <span
                        class="text-danger"><?php if(isset($kolom3kanan[1])) echo $kolom3kanan[1]['total_kanan'] . "[kanan] " . $kolom3kanan[1]['point_pasangan'] ?></span>
                    </div>
                    <?php if(isset($kolom3kanan)){?>
                    <?php }
                  } ?>
                  </td>

                </tr>
              </table>
            </div>
          </div>
      </section>
    </div>


  </div>
  <?php $this->load->view("_partials/footer.php")?>
  <?php $this->load->view("_partials/js.php")?>
</body>

</html>