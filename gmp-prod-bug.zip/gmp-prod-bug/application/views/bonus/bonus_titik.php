<!DOCTYPE html>
<html lang="id">

<head>
  <?php $this->load->view("_partials/head.php") ?>
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />
  <style>
    .table td[rowspan] {
      vertical-align: middle;
      text-align: center;
    }

    .table {
      text-align: center;
    }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark" style="background-color:#1F6521;">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-sm-inline-block">
          <a href="#" class="nav-link">
            <?= $title; ?>
          </a>
        </li>
      </ul>
    </nav>
    <?php $this->load->view("templates/sidebar.php") ?>

    <div class="content-wrapper">
      <section class="content pt-3">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h3>Laporan Bonus Titik</h3>
              <button style="margin-bottom: 15px;" class="btn btn-primary">Total Bonus Sponsor : <?= "Rp " . number_format($sum_bonus['amount'] ?? 0, 0, ',', '.') ?></button>
              <table id="bonus-titik" class="table table-bordered">
                <thead>
                  <tr>
                    <th>Member Id</th>
                    <th>Nama Member</th>
                    <th>Bonus Titik</th>
                    <th>Date</th>
                  </tr>
                </thead>
                
                <tbody>
                  <?php $no = 1;
                  // var_dump($sum_bonus);
                  foreach ($bonus as $bonus) : ?>
                    <tr>
                      <td><a href="<?= base_url('detail_member/' . $bonus->member_id) ?>"><?= $bonus->member_id ?></a></td>
                      <td><?= $bonus->nama ?></td>
                      <td><?= "Rp " . number_format($bonus->amount, 0, ',', '.') ?></td>
                      <td><?= $bonus->created_at ?></td>
                    </tr>
                  <?php endforeach; ?>
              </table>
            </div>
          </div>
      </section>
    </div>


  </div>
  <?php $this->load->view("_partials/footer.php") ?>
  <?php $this->load->view("_partials/js.php") ?>
  <script>
  $(document).ready(function() {
    $('#bonus-titik').DataTable();
  });
  </script>
</body>

</html>